// ============================================================================
// ZUSTAND STORE - État global de l'application
// ============================================================================

import { create } from 'zustand';
import type { Patient, GlycemicEntry, TelemedicineMessage, User } from '@/types';
import { mockPatients, mockGlycemicEntries, mockTelemedicineMessages, mockUser } from './mockData';

interface AppState {
  // Auth
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;

  // Navigation
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  currentPage: string;
  setCurrentPage: (page: string) => void;

  // Patients
  patients: Patient[];
  selectedPatientId: string | null;
  selectedPatient: Patient | null;
  selectPatient: (id: string | null) => void;
  addPatient: (patient: Patient) => void;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
  deletePatient: (id: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  riskFilter: string | null;
  setRiskFilter: (filter: string | null) => void;
  statusFilter: string | null;
  setStatusFilter: (filter: string | null) => void;

  // Glycemic entries
  glycemicEntries: GlycemicEntry[];
  addGlycemicEntry: (entry: GlycemicEntry) => void;

  // Telemedicine
  messages: TelemedicineMessage[];
  markMessageRead: (id: string) => void;

  // UI notifications
  toasts: Array<{ id: string; message: string; type: 'success' | 'error' | 'warning' | 'info' }>;
  addToast: (message: string, type: 'success' | 'error' | 'warning' | 'info') => void;
  removeToast: (id: string) => void;
}

export const useStore = create<AppState>((set, get) => ({
  // Auth
  user: null,
  isAuthenticated: false,
  login: (email: string, _password: string) => {
    if (email === 'doc@dgpro.dz' || email === 'admin') {
      set({ user: mockUser, isAuthenticated: true });
      return true;
    }
    return false;
  },
  logout: () => set({ user: null, isAuthenticated: false, selectedPatientId: null, selectedPatient: null }),

  // Navigation
  sidebarCollapsed: false,
  toggleSidebar: () => set(s => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  currentPage: 'dashboard',
  setCurrentPage: (page) => set({ currentPage: page }),

  // Patients
  patients: mockPatients,
  selectedPatientId: null,
  selectedPatient: null,
  selectPatient: (id) => {
    if (!id) {
      set({ selectedPatientId: null, selectedPatient: null });
      return;
    }
    const patient = get().patients.find(p => p.id === id) || null;
    set({ selectedPatientId: id, selectedPatient: patient });
  },
  addPatient: (patient) => set(s => ({ patients: [...s.patients, patient] })),
  updatePatient: (id, updates) => set(s => ({
    patients: s.patients.map(p => p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p),
    selectedPatient: s.selectedPatientId === id && s.selectedPatient ? { ...s.selectedPatient, ...updates, updatedAt: new Date().toISOString() } : s.selectedPatient,
  })),
  deletePatient: (id) => set(s => ({
    patients: s.patients.filter(p => p.id !== id),
    selectedPatientId: s.selectedPatientId === id ? null : s.selectedPatientId,
    selectedPatient: s.selectedPatientId === id ? null : s.selectedPatient,
  })),
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  riskFilter: null,
  setRiskFilter: (filter) => set({ riskFilter: filter }),
  statusFilter: null,
  setStatusFilter: (filter) => set({ statusFilter: filter }),

  // Glycemic
  glycemicEntries: mockGlycemicEntries,
  addGlycemicEntry: (entry) => set(s => ({ glycemicEntries: [...s.glycemicEntries, entry] })),

  // Telemedicine
  messages: mockTelemedicineMessages,
  markMessageRead: (id) => set(s => ({
    messages: s.messages.map(m => m.id === id ? { ...m, read: true } : m),
  })),

  // Toasts
  toasts: [],
  addToast: (message, type) => {
    const id = Math.random().toString(36).substr(2, 9);
    set(s => ({ toasts: [...s.toasts, { id, message, type }] }));
    setTimeout(() => get().removeToast(id), 4000);
  },
  removeToast: (id) => set(s => ({ toasts: s.toasts.filter(t => t.id !== id) })),
}));
