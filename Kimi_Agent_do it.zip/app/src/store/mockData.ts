// ============================================================================
// MOCK DATA - Données de test réalistes pour le MVP
// ============================================================================

import type { Patient, GlycemicEntry, BiologyEntry, UltrasoundEntry, ConsultationEntry, TelemedicineMessage, DashboardStats, User } from '@/types';

// --- Utilisateur médecin ---
export const mockUser: User = {
  id: 'doc-001',
  name: 'Dr. Sarah Benali',
  email: 's.benali@clinique-dg.dz',
  role: 'doctor',
};

// --- Helper: calculer l'âge ---
function calculateAge(birthDate: string): number {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) age--;
  return age;
}

// --- Helper: calculer l'IMC ---
function calculateBMI(weight: number, height: number): number {
  const heightM = height / 100;
  return Math.round((weight / (heightM * heightM)) * 10) / 10;
}

// --- Helper: calculer données grossesse ---
function calculatePregnancyData(ddr: string) {
  const ddrDate = new Date(ddr);
  const today = new Date('2025-04-15'); // date fixe pour la démo
  const diffTime = today.getTime() - ddrDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const sa = Math.floor(diffDays / 7);
  const trimester = sa <= 12 ? 1 : sa <= 28 ? 2 : 3;
  const dpaDate = new Date(ddrDate);
  dpaDate.setDate(dpaDate.getDate() + 280);
  const dpa = dpaDate.toISOString().split('T')[0];
  return { gestationalAge: sa, sa, trimester, dpa };
}

// --- Patient template ---
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function createPatient(p: any): Patient {
  const age = calculateAge(p.identity!.birthDate);
  const preBMI = calculateBMI(p.anthropometric!.prePregnancyWeight, p.anthropometric!.height);
  const curBMI = calculateBMI(p.anthropometric!.currentWeight, p.anthropometric!.height);
  const weightGain = Math.round((p.anthropometric!.currentWeight - p.anthropometric!.prePregnancyWeight) * 10) / 10;
  const pregData = p.pregnancy?.ddr ? calculatePregnancyData(p.pregnancy.ddr) : { gestationalAge: null, sa: null, trimester: null, dpa: null };

  return {
    id: p.id || `pat-${Math.random().toString(36).substr(2, 9)}`,
    identity: {
      ...p.identity,
      age,
      phone: p.identity!.phone || '',
      address: p.identity!.address || '',
      profession: p.identity!.profession || '',
      insurance: p.identity!.insurance || '',
      fileNumber: p.identity!.fileNumber || '',
      createdAt: p.createdAt || new Date().toISOString(),
    },
    anthropometric: {
      ...p.anthropometric,
      prePregnancyBMI: preBMI,
      currentBMI: curBMI,
      totalWeightGain: weightGain,
      weightHistory: p.anthropometric!.weightHistory || [
        { date: '2025-01-15', weight: p.anthropometric!.prePregnancyWeight },
        { date: '2025-02-15', weight: p.anthropometric!.prePregnancyWeight + 1.5 },
        { date: '2025-03-15', weight: p.anthropometric!.currentWeight - 1 },
        { date: '2025-04-15', weight: p.anthropometric!.currentWeight },
      ],
    },
    vitals: p.vitals || { bloodPressure: '120/80', heartRate: 72, temperature: 36.6, oxygenSaturation: 98 },
    obstetricHistory: p.obstetricHistory || { geste: 0, parite: 0, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: false, csection: false },
    medicalHistory: p.medicalHistory || { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: p.familyHistory || { diabetes: false, hta: false, obesity: false, cardiovascularDisease: false },
    pregnancy: {
      ddr: p.pregnancy?.ddr || null,
      ...pregData,
    },
    diabetes: p.diabetes || {
      type: 'dg',
      diagnosisDate: null,
      treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false },
    },
    glycemicEntries: p.glycemicEntries || [],
    biologyEntries: p.biologyEntries || [],
    ultrasounds: p.ultrasounds || [],
    consultations: p.consultations || [],
    delivery: p.delivery || {
      date: null, mode: null, preeclampsia: false, hemorrhage: false, infection: false, hospitalization: false,
      newbornSex: null, newbornWeight: null, newbornHeight: null, newbornHeadCircumference: null,
      apgar1: null, apgar5: null, macrosomia: false, neonatalHypoglycemia: false, respiratoryDistress: false, nicuHospitalization: false,
    },
    postpartum: p.postpartum || {
      motherWeight: null, motherBMI: null, breastfeeding: false, contraception: null,
      fastingGlucose: null, hba1c: null, postpartumHgpoDate: null, postpartumHgpoResults: null, postpartumClassification: null,
      childWeight: null, childHeight: null, childFeedingMode: null, childHospitalizations: null,
    },
    riskLevel: p.riskLevel || 'low',
    status: p.status || 'active',
    createdAt: p.createdAt || new Date().toISOString(),
    updatedAt: p.updatedAt || new Date().toISOString(),
  };
}

// --- 20 patientes réalistes ---
export const mockPatients: Patient[] = [
  createPatient({
    id: 'pat-001',
    identity: { firstName: 'Amel', lastName: 'Khedir', birthDate: '1992-03-14', phone: '0550-12-34-56', address: 'Alger-Centre', profession: 'Enseignante', insurance: 'CNAS', fileNumber: 'DG-2025-001' },
    anthropometric: { height: 165, prePregnancyWeight: 68, currentWeight: 74.5, weightHistory: [] },
    vitals: { bloodPressure: '125/82', heartRate: 78, temperature: 36.5, oxygenSaturation: 99 },
    obstetricHistory: { geste: 2, parite: 1, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: true, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: true, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: true, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-09-10' },
    diabetes: { type: 'dg', diagnosisDate: '2025-01-15', hgpo75g: { fasting: 0.92, oneHour: 9.1, twoHours: 8.4, interpretation: 'Diabète gestationnel (2 valeurs anormales)' }, treatments: { diet: true, physicalActivity: true, metformin: true, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'high',
    status: 'active',
    createdAt: '2025-01-10T08:30:00Z',
  }),
  createPatient({
    id: 'pat-002',
    identity: { firstName: 'Lyna', lastName: 'Boudraa', birthDate: '1988-07-22', phone: '0771-23-45-67', address: 'Bab Ezzouar', profession: 'Comptable', insurance: 'CASNOS', fileNumber: 'DG-2025-002' },
    anthropometric: { height: 158, prePregnancyWeight: 82, currentWeight: 88 },
    vitals: { bloodPressure: '130/85', heartRate: 80, temperature: 36.7, oxygenSaturation: 97 },
    obstetricHistory: { geste: 3, parite: 2, miscarriages: 1, mfiu: 0, macrosomia: true, prematurity: false, preeclampsia: false, previousGDM: true, csection: true },
    medicalHistory: { hta: true, dyslipidemia: true, obesity: true, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: true, obesity: true, cardiovascularDisease: true },
    pregnancy: { ddr: '2024-10-05' },
    diabetes: { type: 'dg', diagnosisDate: '2025-02-01', hgpo75g: { fasting: 0.96, oneHour: 10.2, twoHours: 9.1, interpretation: 'Diabète gestationnel (3 valeurs anormales)' }, treatments: { diet: true, physicalActivity: false, metformin: true, basalInsulin: true, rapidInsulin: true, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'critical',
    status: 'active',
    createdAt: '2025-01-25T09:00:00Z',
  }),
  createPatient({
    id: 'pat-003',
    identity: { firstName: 'Nadia', lastName: 'Meziani', birthDate: '1995-11-03', phone: '0662-34-56-78', address: 'Hydra', profession: 'Ingénieure', insurance: 'CNAS', fileNumber: 'DG-2025-003' },
    anthropometric: { height: 170, prePregnancyWeight: 60, currentWeight: 65 },
    vitals: { bloodPressure: '110/70', heartRate: 68, temperature: 36.4, oxygenSaturation: 99 },
    obstetricHistory: { geste: 1, parite: 0, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: false, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: false, hta: false, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-11-20' },
    diabetes: { type: 'dg', diagnosisDate: '2025-03-01', hgpo75g: { fasting: 0.88, oneHour: 8.5, twoHours: 7.9, interpretation: 'Diabète gestationnel (1 valeur anormale à 1h)' }, treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'low',
    status: 'active',
    createdAt: '2025-02-15T10:00:00Z',
  }),
  createPatient({
    id: 'pat-004',
    identity: { firstName: 'Fatiha', lastName: 'Zerrouki', birthDate: '1985-01-18', phone: '0553-45-67-89', address: 'El Biar', profession: 'Médecin', insurance: 'CNAS', fileNumber: 'DG-2025-004' },
    anthropometric: { height: 162, prePregnancyWeight: 75, currentWeight: 81 },
    vitals: { bloodPressure: '135/88', heartRate: 82, temperature: 36.8, oxygenSaturation: 96 },
    obstetricHistory: { geste: 4, parite: 3, miscarriages: 1, mfiu: 0, macrosomia: false, prematurity: true, preeclampsia: true, previousGDM: true, csection: true },
    medicalHistory: { hta: true, dyslipidemia: false, obesity: true, thyroidPathology: false, heartDisease: false, nephropathy: true, other: 'Micronéphropathie' },
    familyHistory: { diabetes: true, hta: true, obesity: false, cardiovascularDisease: true },
    pregnancy: { ddr: '2024-08-15' },
    diabetes: { type: 'dt2', diagnosisDate: '2020-03-10', diabetesDuration: 5, preconceptionConsultation: true, preconceptionHbA1c: 7.2, preconceptionTreatment: 'Metformine + Glargine', existingComplications: 'Rétinopathie légère, microalbuminurie', treatments: { diet: true, physicalActivity: true, metformin: true, basalInsulin: true, rapidInsulin: true, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'critical',
    status: 'active',
    createdAt: '2024-09-01T08:00:00Z',
  }),
  createPatient({
    id: 'pat-005',
    identity: { firstName: 'Samira', lastName: 'Touati', birthDate: '1990-05-30', phone: '0774-56-78-90', address: 'Kouba', profession: 'Pharmacienne', insurance: 'CASNOS', fileNumber: 'DG-2025-005' },
    anthropometric: { height: 168, prePregnancyWeight: 55, currentWeight: 62 },
    vitals: { bloodPressure: '118/75', heartRate: 70, temperature: 36.5, oxygenSaturation: 99 },
    obstetricHistory: { geste: 2, parite: 1, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: false, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: false, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-12-01' },
    diabetes: { type: 'dg', diagnosisDate: '2025-03-10', hgpo75g: { fasting: 0.90, oneHour: 9.8, twoHours: 7.5, interpretation: 'Diabète gestationnel (1 valeur anormale à 1h)' }, treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'medium',
    status: 'active',
    createdAt: '2025-03-05T11:00:00Z',
  }),
  createPatient({
    id: 'pat-006',
    identity: { firstName: 'Karima', lastName: 'Hamidi', birthDate: '1987-09-12', phone: '0665-67-89-01', address: 'Birkhadem', profession: 'Avocate', insurance: 'CNAS', fileNumber: 'DG-2025-006' },
    anthropometric: { height: 160, prePregnancyWeight: 78, currentWeight: 84 },
    vitals: { bloodPressure: '128/80', heartRate: 76, temperature: 36.6, oxygenSaturation: 98 },
    obstetricHistory: { geste: 3, parite: 2, miscarriages: 1, mfiu: 0, macrosomia: true, prematurity: false, preeclampsia: false, previousGDM: true, csection: true },
    medicalHistory: { hta: false, dyslipidemia: true, obesity: true, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: false, obesity: true, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-07-20' },
    diabetes: { type: 'dg', diagnosisDate: '2024-11-01', hgpo75g: { fasting: 0.94, oneHour: 9.5, twoHours: 8.2, interpretation: 'Diabète gestationnel (2 valeurs anormales)' }, treatments: { diet: true, physicalActivity: true, metformin: true, basalInsulin: true, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'high',
    status: 'monitored',
    createdAt: '2024-10-15T09:30:00Z',
  }),
  createPatient({
    id: 'pat-007',
    identity: { firstName: 'Yasmina', lastName: 'Belkacem', birthDate: '1993-04-25', phone: '0556-78-90-12', address: 'Dar El Beïda', profession: 'Architecte', insurance: 'CNAS', fileNumber: 'DG-2025-007' },
    anthropometric: { height: 172, prePregnancyWeight: 63, currentWeight: 70 },
    vitals: { bloodPressure: '115/72', heartRate: 72, temperature: 36.5, oxygenSaturation: 99 },
    obstetricHistory: { geste: 1, parite: 0, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: false, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: true, heartDisease: false, nephropathy: false, other: 'Hypothyroïdie' },
    familyHistory: { diabetes: false, hta: false, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-10-18' },
    diabetes: { type: 'dt1', diagnosisDate: '2010-06-15', diabetesDuration: 15, preconceptionConsultation: true, preconceptionHbA1c: 7.0, preconceptionTreatment: 'Pompe à insuline', existingComplications: '', treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: true, hybridClosedLoop: false } },
    riskLevel: 'high',
    status: 'active',
    createdAt: '2024-11-01T10:00:00Z',
  }),
  createPatient({
    id: 'pat-008',
    identity: { firstName: 'Rachida', lastName: 'Mansouri', birthDate: '1991-08-08', phone: '0777-89-01-23', address: 'Bologhine', profession: 'Infirmière', insurance: 'CNAS', fileNumber: 'DG-2025-008' },
    anthropometric: { height: 164, prePregnancyWeight: 70, currentWeight: 76 },
    vitals: { bloodPressure: '122/78', heartRate: 74, temperature: 36.6, oxygenSaturation: 98 },
    obstetricHistory: { geste: 2, parite: 1, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: true, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: true, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-09-25' },
    diabetes: { type: 'dg', diagnosisDate: '2025-01-20', hgpo75g: { fasting: 0.91, oneHour: 8.9, twoHours: 8.0, interpretation: 'Diabète gestationnel (1 valeur anormale à 1h)' }, treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'medium',
    status: 'active',
    createdAt: '2025-01-28T08:00:00Z',
  }),
  createPatient({
    id: 'pat-009',
    identity: { firstName: 'Aïcha', lastName: 'Sahnoun', birthDate: '1989-12-01', phone: '0668-90-12-34', address: 'Rouïba', profession: 'Cadre bancaire', insurance: 'CASNOS', fileNumber: 'DG-2025-009' },
    anthropometric: { height: 159, prePregnancyWeight: 85, currentWeight: 92 },
    vitals: { bloodPressure: '138/90', heartRate: 84, temperature: 36.7, oxygenSaturation: 96 },
    obstetricHistory: { geste: 5, parite: 4, miscarriages: 1, mfiu: 0, macrosomia: true, prematurity: false, preeclampsia: true, previousGDM: true, csection: true },
    medicalHistory: { hta: true, dyslipidemia: true, obesity: true, thyroidPathology: false, heartDisease: false, nephropathy: false, other: 'Apnée du sommeil' },
    familyHistory: { diabetes: true, hta: true, obesity: true, cardiovascularDisease: true },
    pregnancy: { ddr: '2024-06-10' },
    diabetes: { type: 'dt2', diagnosisDate: '2018-01-20', diabetesDuration: 7, preconceptionConsultation: false, preconceptionHbA1c: 8.5, preconceptionTreatment: 'Metformine', existingComplications: 'Neuropathie périphérique', treatments: { diet: true, physicalActivity: false, metformin: true, basalInsulin: true, rapidInsulin: true, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'critical',
    status: 'monitored',
    createdAt: '2024-07-15T09:00:00Z',
  }),
  createPatient({
    id: 'pat-010',
    identity: { firstName: 'Meriem', lastName: 'Lounis', birthDate: '1996-02-14', phone: '0559-01-23-45', address: 'Bab Ezzouar', profession: 'Étudiante', insurance: 'CNAS', fileNumber: 'DG-2025-010' },
    anthropometric: { height: 166, prePregnancyWeight: 58, currentWeight: 63 },
    vitals: { bloodPressure: '112/70', heartRate: 70, temperature: 36.4, oxygenSaturation: 99 },
    obstetricHistory: { geste: 1, parite: 0, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: false, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: false, hta: false, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-11-10' },
    diabetes: { type: 'dg', diagnosisDate: '2025-02-20', hgpo75g: { fasting: 0.87, oneHour: 8.3, twoHours: 7.7, interpretation: 'Glycémie normale' }, treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'low',
    status: 'active',
    createdAt: '2025-02-25T10:30:00Z',
  }),
  createPatient({
    id: 'pat-011',
    identity: { firstName: 'Houda', lastName: 'Benmoussa', birthDate: '1986-06-20', phone: '0770-12-34-56', address: 'El Harrach', profession: 'Commerçante', insurance: 'CNAS', fileNumber: 'DG-2025-011' },
    anthropometric: { height: 161, prePregnancyWeight: 80, currentWeight: 87 },
    vitals: { bloodPressure: '132/86', heartRate: 78, temperature: 36.6, oxygenSaturation: 97 },
    obstetricHistory: { geste: 4, parite: 3, miscarriages: 1, mfiu: 0, macrosomia: true, prematurity: true, preeclampsia: false, previousGDM: true, csection: true },
    medicalHistory: { hta: true, dyslipidemia: true, obesity: true, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: true, obesity: true, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-08-01' },
    diabetes: { type: 'dg', diagnosisDate: '2024-10-15', hgpo75g: { fasting: 0.98, oneHour: 10.5, twoHours: 9.0, interpretation: 'Diabète gestationnel (3 valeurs anormales)' }, treatments: { diet: true, physicalActivity: false, metformin: true, basalInsulin: true, rapidInsulin: true, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'critical',
    status: 'monitored',
    createdAt: '2024-09-10T08:00:00Z',
  }),
  createPatient({
    id: 'pat-012',
    identity: { firstName: 'Dalila', lastName: 'Chikhi', birthDate: '1994-10-05', phone: '0661-23-45-67', address: 'Alger-Centre', profession: 'Informaticienne', insurance: 'CNAS', fileNumber: 'DG-2025-012' },
    anthropometric: { height: 169, prePregnancyWeight: 62, currentWeight: 68 },
    vitals: { bloodPressure: '116/74', heartRate: 72, temperature: 36.5, oxygenSaturation: 99 },
    obstetricHistory: { geste: 1, parite: 0, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: false, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: false, hta: false, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-12-15' },
    diabetes: { type: 'dg', diagnosisDate: '2025-03-20', hgpo75g: { fasting: 0.89, oneHour: 8.7, twoHours: 7.6, interpretation: 'Diabète gestationnel (1 valeur anormale à 1h)' }, treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'low',
    status: 'active',
    createdAt: '2025-03-22T09:00:00Z',
  }),
  createPatient({
    id: 'pat-013',
    identity: { firstName: 'Soraya', lastName: 'Amara', birthDate: '1984-03-28', phone: '0552-34-56-78', address: 'Bab El Oued', profession: 'Chef d\'entreprise', insurance: 'CASNOS', fileNumber: 'DG-2025-013' },
    anthropometric: { height: 163, prePregnancyWeight: 72, currentWeight: 79 },
    vitals: { bloodPressure: '126/82', heartRate: 76, temperature: 36.6, oxygenSaturation: 98 },
    obstetricHistory: { geste: 3, parite: 2, miscarriages: 1, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: true, csection: false },
    medicalHistory: { hta: false, dyslipidemia: true, obesity: false, thyroidPathology: true, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: false, obesity: false, cardiovascularDisease: true },
    pregnancy: { ddr: '2024-09-01' },
    diabetes: { type: 'dt1', diagnosisDate: '1999-08-10', diabetesDuration: 26, preconceptionConsultation: true, preconceptionHbA1c: 6.8, preconceptionTreatment: 'Pompe à insuline + capteur', existingComplications: '', treatments: { diet: true, physicalActivity: true, metformin: false, basalInsulin: false, rapidInsulin: false, insulinPump: true, hybridClosedLoop: true } },
    riskLevel: 'high',
    status: 'active',
    createdAt: '2024-09-20T08:30:00Z',
  }),
  createPatient({
    id: 'pat-014',
    identity: { firstName: 'Malika', lastName: 'Djebbar', birthDate: '1992-07-16', phone: '0773-45-67-89', address: 'Kouba', profession: 'Secrétaire', insurance: 'CNAS', fileNumber: 'DG-2025-014' },
    anthropometric: { height: 167, prePregnancyWeight: 65, currentWeight: 71 },
    vitals: { bloodPressure: '120/78', heartRate: 74, temperature: 36.5, oxygenSaturation: 99 },
    obstetricHistory: { geste: 2, parite: 1, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: false, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: true, hta: false, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-10-12' },
    diabetes: { type: 'dg', diagnosisDate: '2025-01-30', hgpo75g: { fasting: 0.93, oneHour: 9.2, twoHours: 8.1, interpretation: 'Diabète gestationnel (2 valeurs anormales)' }, treatments: { diet: true, physicalActivity: true, metformin: true, basalInsulin: false, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'medium',
    status: 'active',
    createdAt: '2025-02-01T10:00:00Z',
  }),
  createPatient({
    id: 'pat-015',
    identity: { firstName: 'Nawel', lastName: 'Bekkouche', birthDate: '1988-11-22', phone: '0664-56-78-90', address: 'Birkhadem', profession: 'Chercheuse', insurance: 'CNAS', fileNumber: 'DG-2025-015' },
    anthropometric: { height: 171, prePregnancyWeight: 68, currentWeight: 75 },
    vitals: { bloodPressure: '124/80', heartRate: 72, temperature: 36.6, oxygenSaturation: 98 },
    obstetricHistory: { geste: 2, parite: 1, miscarriages: 0, mfiu: 0, macrosomia: false, prematurity: false, preeclampsia: false, previousGDM: true, csection: false },
    medicalHistory: { hta: false, dyslipidemia: false, obesity: false, thyroidPathology: false, heartDisease: false, nephropathy: false, other: '' },
    familyHistory: { diabetes: false, hta: true, obesity: false, cardiovascularDisease: false },
    pregnancy: { ddr: '2024-08-20' },
    diabetes: { type: 'dg', diagnosisDate: '2024-11-10', hgpo75g: { fasting: 0.95, oneHour: 9.6, twoHours: 8.3, interpretation: 'Diabète gestationnel (2 valeurs anormales)' }, treatments: { diet: true, physicalActivity: true, metformin: true, basalInsulin: true, rapidInsulin: false, insulinPump: false, hybridClosedLoop: false } },
    riskLevel: 'high',
    status: 'active',
    createdAt: '2024-09-01T09:00:00Z',
  }),
];

// --- Entrées glycémiques mock ---
export const mockGlycemicEntries: GlycemicEntry[] = [
  // Pat-001 (Amel)
  { id: 'ge-001', patientId: 'pat-001', date: '2025-04-10', timePoint: 'beforeBreakfast', value: 92, notes: '', createdAt: '2025-04-10T07:30:00Z' },
  { id: 'ge-002', patientId: 'pat-001', date: '2025-04-10', timePoint: 'afterBreakfast', value: 142, notes: '', createdAt: '2025-04-10T09:30:00Z' },
  { id: 'ge-003', patientId: 'pat-001', date: '2025-04-10', timePoint: 'beforeLunch', value: 88, notes: '', createdAt: '2025-04-10T12:00:00Z' },
  { id: 'ge-004', patientId: 'pat-001', date: '2025-04-10', timePoint: 'afterLunch', value: 138, notes: '', createdAt: '2025-04-10T14:00:00Z' },
  { id: 'ge-005', patientId: 'pat-001', date: '2025-04-10', timePoint: 'beforeDinner', value: 95, notes: '', createdAt: '2025-04-10T19:00:00Z' },
  { id: 'ge-006', patientId: 'pat-001', date: '2025-04-10', timePoint: 'afterDinner', value: 128, notes: '', createdAt: '2025-04-10T21:00:00Z' },
  { id: 'ge-007', patientId: 'pat-001', date: '2025-04-11', timePoint: 'beforeBreakfast', value: 90, notes: '', createdAt: '2025-04-11T07:30:00Z' },
  { id: 'ge-008', patientId: 'pat-001', date: '2025-04-11', timePoint: 'afterBreakfast', value: 156, notes: 'Petit-déj copieux', createdAt: '2025-04-11T09:30:00Z' },
  { id: 'ge-009', patientId: 'pat-001', date: '2025-04-11', timePoint: 'beforeLunch', value: 92, notes: '', createdAt: '2025-04-11T12:00:00Z' },
  { id: 'ge-010', patientId: 'pat-001', date: '2025-04-11', timePoint: 'afterLunch', value: 132, notes: '', createdAt: '2025-04-11T14:00:00Z' },
  { id: 'ge-011', patientId: 'pat-001', date: '2025-04-11', timePoint: 'beforeDinner', value: 98, notes: '', createdAt: '2025-04-11T19:00:00Z' },
  { id: 'ge-012', patientId: 'pat-001', date: '2025-04-11', timePoint: 'afterDinner', value: 145, notes: '', createdAt: '2025-04-11T21:00:00Z' },
  { id: 'ge-013', patientId: 'pat-001', date: '2025-04-12', timePoint: 'beforeBreakfast', value: 88, notes: '', createdAt: '2025-04-12T07:30:00Z' },
  { id: 'ge-014', patientId: 'pat-001', date: '2025-04-12', timePoint: 'afterBreakfast', value: 134, notes: '', createdAt: '2025-04-12T09:30:00Z' },
  { id: 'ge-015', patientId: 'pat-001', date: '2025-04-12', timePoint: 'beforeLunch', value: 85, notes: '', createdAt: '2025-04-12T12:00:00Z' },
  { id: 'ge-016', patientId: 'pat-001', date: '2025-04-12', timePoint: 'afterLunch', value: 125, notes: '', createdAt: '2025-04-12T14:00:00Z' },
  { id: 'ge-017', patientId: 'pat-001', date: '2025-04-12', timePoint: 'beforeDinner', value: 91, notes: '', createdAt: '2025-04-12T19:00:00Z' },
  { id: 'ge-018', patientId: 'pat-001', date: '2025-04-12', timePoint: 'afterDinner', value: 130, notes: '', createdAt: '2025-04-12T21:00:00Z' },
  { id: 'ge-019', patientId: 'pat-001', date: '2025-04-13', timePoint: 'beforeBreakfast', value: 94, notes: '', createdAt: '2025-04-13T07:30:00Z' },
  { id: 'ge-020', patientId: 'pat-001', date: '2025-04-13', timePoint: 'afterBreakfast', value: 148, notes: '', createdAt: '2025-04-13T09:30:00Z' },
  { id: 'ge-021', patientId: 'pat-001', date: '2025-04-13', timePoint: 'beforeLunch', value: 89, notes: '', createdAt: '2025-04-13T12:00:00Z' },
  { id: 'ge-022', patientId: 'pat-001', date: '2025-04-13', timePoint: 'afterLunch', value: 140, notes: '', createdAt: '2025-04-13T14:00:00Z' },
  { id: 'ge-023', patientId: 'pat-001', date: '2025-04-13', timePoint: 'beforeDinner', value: 96, notes: '', createdAt: '2025-04-13T19:00:00Z' },
  { id: 'ge-024', patientId: 'pat-001', date: '2025-04-13', timePoint: 'afterDinner', value: 138, notes: '', createdAt: '2025-04-13T21:00:00Z' },
  { id: 'ge-025', patientId: 'pat-001', date: '2025-04-14', timePoint: 'beforeBreakfast', value: 87, notes: '', createdAt: '2025-04-14T07:30:00Z' },
  { id: 'ge-026', patientId: 'pat-001', date: '2025-04-14', timePoint: 'afterBreakfast', value: 128, notes: '', createdAt: '2025-04-14T09:30:00Z' },
  { id: 'ge-027', patientId: 'pat-001', date: '2025-04-14', timePoint: 'beforeLunch', value: 84, notes: '', createdAt: '2025-04-14T12:00:00Z' },
  { id: 'ge-028', patientId: 'pat-001', date: '2025-04-14', timePoint: 'afterLunch', value: 122, notes: '', createdAt: '2025-04-14T14:00:00Z' },
  { id: 'ge-029', patientId: 'pat-001', date: '2025-04-14', timePoint: 'beforeDinner', value: 90, notes: '', createdAt: '2025-04-14T19:00:00Z' },
  { id: 'ge-030', patientId: 'pat-001', date: '2025-04-14', timePoint: 'afterDinner', value: 135, notes: '', createdAt: '2025-04-14T21:00:00Z' },
  // Pat-002 (Lyna) - glycémies plus élevées
  { id: 'ge-031', patientId: 'pat-002', date: '2025-04-14', timePoint: 'beforeBreakfast', value: 110, notes: '', createdAt: '2025-04-14T07:00:00Z' },
  { id: 'ge-032', patientId: 'pat-002', date: '2025-04-14', timePoint: 'afterBreakfast', value: 180, notes: 'Hyperglycémie post-prandiale', createdAt: '2025-04-14T09:00:00Z' },
  { id: 'ge-033', patientId: 'pat-002', date: '2025-04-14', timePoint: 'beforeLunch', value: 125, notes: '', createdAt: '2025-04-14T12:00:00Z' },
  { id: 'ge-034', patientId: 'pat-002', date: '2025-04-14', timePoint: 'afterLunch', value: 195, notes: 'Hyperglycémie sévère', createdAt: '2025-04-14T14:00:00Z' },
  { id: 'ge-035', patientId: 'pat-002', date: '2025-04-14', timePoint: 'beforeDinner', value: 118, notes: '', createdAt: '2025-04-14T19:00:00Z' },
  { id: 'ge-036', patientId: 'pat-002', date: '2025-04-14', timePoint: 'afterDinner', value: 172, notes: '', createdAt: '2025-04-14T21:00:00Z' },
];

// --- Entrées biologie mock ---
export const mockBiologyEntries: BiologyEntry[] = [
  { id: 'be-001', patientId: 'pat-001', date: '2025-01-15', hba1c: 6.8, creatinine: 65, urea: 3.2, asat: 22, alat: 25, tsh: 2.1 },
  { id: 'be-002', patientId: 'pat-001', date: '2025-02-15', hba1c: 6.2, creatinine: 62, urea: 3.0, asat: 20, alat: 23, tsh: 1.9 },
  { id: 'be-003', patientId: 'pat-001', date: '2025-03-15', hba1c: 5.9, creatinine: 60, urea: 2.8, asat: 19, alat: 22, tsh: 1.8 },
  { id: 'be-004', patientId: 'pat-001', date: '2025-04-10', hba1c: 5.7, creatinine: 58, urea: 2.7, asat: 18, alat: 21, tsh: 1.7 },
  { id: 'be-005', patientId: 'pat-004', date: '2024-09-01', hba1c: 7.8, creatinine: 95, urea: 5.5, asat: 35, alat: 42, tsh: 3.2 },
  { id: 'be-006', patientId: 'pat-004', date: '2024-10-15', hba1c: 7.2, creatinine: 88, urea: 5.0, asat: 30, alat: 38, tsh: 2.8 },
  { id: 'be-007', patientId: 'pat-004', date: '2024-12-01', hba1c: 6.8, creatinine: 82, urea: 4.5, asat: 26, alat: 32, tsh: 2.5 },
  { id: 'be-008', patientId: 'pat-004', date: '2025-02-15', hba1c: 6.5, creatinine: 78, urea: 4.2, asat: 24, alat: 28, tsh: 2.2 },
  { id: 'be-009', patientId: 'pat-004', date: '2025-04-01', hba1c: 6.3, creatinine: 75, urea: 4.0, asat: 22, alat: 26, tsh: 2.0 },
];

// --- Échographies mock ---
export const mockUltrasounds: UltrasoundEntry[] = [
  { id: 'us-001', patientId: 'pat-001', date: '2025-01-20', bpd: 28, hc: 105, ac: 95, fl: 18, estimatedFetalWeight: 320, percentile: 45, amnioticFluid: 'Normal', doppler: 'Normal', presentation: 'Céphalique', gestationalAgeAtExam: 19 },
  { id: 'us-002', patientId: 'pat-001', date: '2025-02-20', bpd: 52, hc: 185, ac: 165, fl: 35, estimatedFetalWeight: 850, percentile: 50, amnioticFluid: 'Normal', doppler: 'Normal', presentation: 'Céphalique', gestationalAgeAtExam: 23 },
  { id: 'us-003', patientId: 'pat-001', date: '2025-03-25', bpd: 72, hc: 260, ac: 230, fl: 52, estimatedFetalWeight: 1450, percentile: 48, amnioticFluid: 'Normal', doppler: 'Normal', presentation: 'Céphalique', gestationalAgeAtExam: 28 },
  { id: 'us-004', patientId: 'pat-001', date: '2025-04-10', bpd: 82, hc: 295, ac: 268, fl: 62, estimatedFetalWeight: 1920, percentile: 52, amnioticFluid: 'Normal', doppler: 'Normal', presentation: 'Céphalique', gestationalAgeAtExam: 31 },
  { id: 'us-005', patientId: 'pat-004', date: '2024-10-10', bpd: 45, hc: 160, ac: 140, fl: 30, estimatedFetalWeight: 620, percentile: 55, amnioticFluid: 'Normal', doppler: 'Normal', presentation: 'Céphalique', gestationalAgeAtExam: 21 },
  { id: 'us-006', patientId: 'pat-004', date: '2024-12-20', bpd: 68, hc: 245, ac: 215, fl: 48, estimatedFetalWeight: 1280, percentile: 58, amnioticFluid: 'Normal', doppler: 'Normal', presentation: 'Céphalique', gestationalAgeAtExam: 31 },
  { id: 'us-007', patientId: 'pat-004', date: '2025-02-28', bpd: 78, hc: 280, ac: 255, fl: 58, estimatedFetalWeight: 1750, percentile: 60, amnioticFluid: 'Normal', doppler: 'Normal', presentation: 'Céphalique', gestationalAgeAtExam: 41 },
];

// --- Consultations mock ---
export const mockConsultations: ConsultationEntry[] = [
  { id: 'co-001', patientId: 'pat-001', date: '2025-01-15', motif: 'Bilan de grossesse', clinicalExam: 'Bonne condition générale, TA 125/82, MU présente', glycemicAnalysis: 'HGPO 75g anormal, diagnostic de DG', obstetricAnalysis: 'Grossesse unique, évolution normale', diagnosis: 'Diabète gestationnel', treatmentPlan: 'Régime + Metformine 500mg x2/j', advice: 'Auto-surveillance glycémique x6/j' },
  { id: 'co-002', patientId: 'pat-001', date: '2025-02-15', motif: 'Suivi DG', clinicalExam: 'PDS +2kg, TA 122/80', glycemicAnalysis: 'Glycémies moyennes en amélioration', obstetricAnalysis: 'Échographie normale, croissance conforme', diagnosis: 'DG équilibré sous Metformine', treatmentPlan: 'Continuer Metformine, ajuster régime', advice: 'Maintenir activité physique' },
  { id: 'co-003', patientId: 'pat-001', date: '2025-03-15', motif: 'Suivi mensuel', clinicalExam: 'PDS +3.5kg total, TA 120/78', glycemicAnalysis: 'Bon équilibre glycémique', obstetricAnalysis: 'Croissance fœtale normale (48e percentile)', diagnosis: 'DG bien contrôlé', treatmentPlan: 'Poursuivre traitement actuel', advice: 'Préparation à l\'accouchement' },
];

// --- Messages télémédecine mock ---
export const mockTelemedicineMessages: TelemedicineMessage[] = [
  { id: 'tm-001', patientId: 'pat-001', patientName: 'Amel Khedir', type: 'glucose', content: 'Glycémie ce matin à jeun : 0.95 g/L', timestamp: '2025-04-15T07:30:00Z', read: true },
  { id: 'tm-002', patientId: 'pat-002', patientName: 'Lyna Boudraa', type: 'hypo', content: 'J\'ai eu une hypoglycémie cette nuit à 3h, 0.55 g/L', timestamp: '2025-04-15T03:15:00Z', read: false },
  { id: 'tm-003', patientId: 'pat-001', patientName: 'Amel Khedir', type: 'weight', content: 'Poids aujourd\'hui : 75.2 kg', timestamp: '2025-04-14T08:00:00Z', read: true },
  { id: 'tm-004', patientId: 'pat-003', patientName: 'Nadia Meziani', type: 'glucose', content: 'Glycémies de la journée : jeun 0.82, AP 1.20', timestamp: '2025-04-14T20:00:00Z', read: false },
  { id: 'tm-005', patientId: 'pat-004', patientName: 'Fatiha Zerrouki', type: 'bp', content: 'Tension ce soir : 14/9', timestamp: '2025-04-14T19:00:00Z', read: false },
  { id: 'tm-006', patientId: 'pat-001', patientName: 'Amel Khedir', type: 'file', content: 'Résultats de la NFS du 10/04', timestamp: '2025-04-10T10:00:00Z', read: true, attachments: ['nfs-2025-04-10.pdf'] },
];

// --- Stats dashboard ---
export function getDashboardStats(): DashboardStats {
  return {
    totalPatients: mockPatients.length,
    newPatientsThisMonth: 3,
    todayConsultations: 8,
    upcomingAppointments: 12,
    atRiskPatients: mockPatients.filter(p => p.riskLevel === 'high' || p.riskLevel === 'critical').length,
    activeAlerts: 4,
  };
}

// --- Distribution par type de diabète ---
export function getDiabetesTypeDistribution() {
  const dist = { dg: 0, dt1: 0, dt2: 0, other: 0 };
  mockPatients.forEach(p => {
    dist[p.diabetes.type]++;
  });
  return [
    { name: 'DG', value: dist.dg, color: '#2C5F7C' },
    { name: 'DT1', value: dist.dt1, color: '#3B82F6' },
    { name: 'DT2', value: dist.dt2, color: '#EF4444' },
    { name: 'Autre', value: dist.other, color: '#6B7280' },
  ];
}

// --- Distribution par trimestre ---
export function getTrimesterDistribution() {
  const dist = { t1: 0, t2: 0, t3: 0, unknown: 0 };
  mockPatients.forEach(p => {
    if (p.pregnancy.trimester === 1) dist.t1++;
    else if (p.pregnancy.trimester === 2) dist.t2++;
    else if (p.pregnancy.trimester === 3) dist.t3++;
    else dist.unknown++;
  });
  return [
    { name: 'T1', value: dist.t1, color: '#10B981' },
    { name: 'T2', value: dist.t2, color: '#F59E0B' },
    { name: 'T3', value: dist.t3, color: '#EF4444' },
    { name: 'N/A', value: dist.unknown, color: '#6B7280' },
  ];
}

// --- Activité mensuelle (consultations) ---
export function getMonthlyActivity() {
  return [
    { month: 'Sep', consultations: 12, newPatients: 3 },
    { month: 'Oct', consultations: 18, newPatients: 4 },
    { month: 'Nov', consultations: 22, newPatients: 5 },
    { month: 'Déc', consultations: 20, newPatients: 3 },
    { month: 'Jan', consultations: 25, newPatients: 4 },
    { month: 'Fév', consultations: 28, newPatients: 5 },
    { month: 'Mar', consultations: 24, newPatients: 3 },
    { month: 'Avr', consultations: 30, newPatients: 4 },
  ];
}
