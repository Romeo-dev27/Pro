// ============================================================================
// TYPES MÉDICAUX - DiabeGest Pro
// Application de gestion des grossesses diabétiques
// ============================================================================

// --- Données administratives ---
export interface PatientIdentity {
  id: string;
  firstName: string;
  lastName: string;
  birthDate: string; // ISO date
  age: number; // calculé automatiquement
  phone: string;
  address: string;
  profession: string;
  insurance: string;
  fileNumber: string;
  createdAt: string;
}

// --- Données anthropométriques ---
export interface AnthropometricData {
  height: number; // cm
  prePregnancyWeight: number; // kg
  currentWeight: number; // kg
  prePregnancyBMI: number; // calculé
  currentBMI: number; // calculé
  totalWeightGain: number; // calculé
  weightHistory: WeightEntry[];
}

export interface WeightEntry {
  date: string;
  weight: number;
}

// --- Constantes vitales ---
export interface VitalSigns {
  bloodPressure: string; // ex: "120/80"
  heartRate: number; // bpm
  temperature: number; // °C
  oxygenSaturation: number; // %
}

// --- Antécédents obstétricaux ---
export interface ObstetricHistory {
  geste: number; // nombre de grossesses
  parite: number; // nombre d'accouchements
  miscarriages: number;
  mfiu: number; // mort fœtale in utero
  macrosomia: boolean;
  prematurity: boolean;
  preeclampsia: boolean;
  previousGDM: boolean; // diabète gestationnel antérieur
  csection: boolean;
}

// --- Antécédents médicaux ---
export interface MedicalHistory {
  hta: boolean; // hypertension artérielle
  dyslipidemia: boolean;
  obesity: boolean;
  thyroidPathology: boolean;
  heartDisease: boolean;
  nephropathy: boolean;
  other: string;
}

// --- Antécédents familiaux ---
export interface FamilyHistory {
  diabetes: boolean;
  hta: boolean;
  obesity: boolean;
  cardiovascularDisease: boolean;
}

// --- Données de grossesse ---
export interface PregnancyData {
  ddr: string | null; // date dernières règles (ISO)
  gestationalAge: number | null; // âge gestationnel en semaines
  sa: number | null; // semaines d'aménorrhée
  trimester: number | null; // 1, 2, ou 3
  dpa: string | null; // date prévue d'accouchement
}

// --- Diabète ---
export type DiabetesType = 'dg' | 'dt1' | 'dt2' | 'other';

export interface DiabetesData {
  type: DiabetesType;
  diagnosisDate: string | null;
  // Pour diabète gestationnel
  hgpo75g?: {
    fasting: number | null;
    oneHour: number | null;
    twoHours: number | null;
    interpretation: string;
  };
  // Pour grossesse diabétique préexistante
  diabetesDuration?: number | null; // années
  preconceptionConsultation?: boolean;
  preconceptionHbA1c?: number | null;
  preconceptionTreatment?: string;
  existingComplications?: string;
  // Traitements
  treatments: DiabetesTreatment;
}

export interface DiabetesTreatment {
  diet: boolean;
  physicalActivity: boolean;
  metformin: boolean;
  basalInsulin: boolean;
  rapidInsulin: boolean;
  insulinPump: boolean;
  hybridClosedLoop: boolean;
}

// --- Cycle glycémique ---
export type GlycemicTimePoint =
  | 'beforeBreakfast'
  | 'afterBreakfast'
  | 'beforeLunch'
  | 'afterLunch'
  | 'beforeDinner'
  | 'afterDinner'
  | 'nighttime';

export interface GlycemicEntry {
  id: string;
  patientId: string;
  date: string;
  timePoint: GlycemicTimePoint;
  value: number; // mg/dL
  notes?: string;
  createdAt: string;
}

export interface GlycemicCycleDay {
  date: string;
  entries: Partial<Record<GlycemicTimePoint, GlycemicEntry>>;
  dailyAverage: number | null;
  inTargetPercentage: number | null;
  hyperglycemiaCount: number;
  hypoglycemiaCount: number;
}

// --- Biologie ---
export interface BiologyEntry {
  id: string;
  patientId: string;
  date: string;
  hba1c?: number | null;
  nfs?: string | null;
  ferritin?: number | null;
  creatinine?: number | null;
  urea?: number | null;
  asat?: number | null;
  alat?: number | null;
  tsh?: number | null;
  ecbu?: string | null;
  albuminuria?: number | null;
  proteinuria?: number | null;
  lipidProfile?: string | null;
}

// --- Échographie obstétricale ---
export interface UltrasoundEntry {
  id: string;
  patientId: string;
  date: string;
  bpd: number | null; // biparietal
  hc: number | null; // périmètre crânien
  ac: number | null; // périmètre abdominal
  fl: number | null; // longueur fémur
  estimatedFetalWeight: number | null; // g
  percentile: number | null;
  amnioticFluid: string | null;
  doppler: string | null;
  presentation: string | null;
  gestationalAgeAtExam: number | null;
}

// --- Consultation ---
export interface ConsultationEntry {
  id: string;
  patientId: string;
  date: string;
  motif: string;
  clinicalExam: string;
  glycemicAnalysis: string;
  obstetricAnalysis: string;
  diagnosis: string;
  treatmentPlan: string;
  advice: string;
  modifiedAt?: string;
  modifiedBy?: string;
}

// --- Accouchement ---
export interface DeliveryData {
  date: string | null;
  mode: string | null; // voie basse, césarienne, forceps...
  preeclampsia: boolean;
  hemorrhage: boolean;
  infection: boolean;
  hospitalization: boolean;
  // Données néonatales
  newbornSex: string | null;
  newbornWeight: number | null;
  newbornHeight: number | null;
  newbornHeadCircumference: number | null;
  apgar1: number | null;
  apgar5: number | null;
  macrosomia: boolean;
  neonatalHypoglycemia: boolean;
  respiratoryDistress: boolean;
  nicuHospitalization: boolean;
}

// --- Post-partum ---
export interface PostpartumData {
  motherWeight: number | null;
  motherBMI: number | null;
  breastfeeding: boolean;
  contraception: string | null;
  fastingGlucose: number | null;
  hba1c: number | null;
  postpartumHgpoDate: string | null;
  postpartumHgpoResults: string | null;
  postpartumClassification: 'normal' | 'prediabetes' | 'diabetes' | null;
  childWeight: number | null;
  childHeight: number | null;
  childFeedingMode: string | null;
  childHospitalizations: string | null;
}

// --- Patient complet (agrégation) ---
export interface Patient {
  id: string;
  identity: PatientIdentity;
  anthropometric: AnthropometricData;
  vitals: VitalSigns;
  obstetricHistory: ObstetricHistory;
  medicalHistory: MedicalHistory;
  familyHistory: FamilyHistory;
  pregnancy: PregnancyData;
  diabetes: DiabetesData;
  glycemicEntries: GlycemicEntry[];
  biologyEntries: BiologyEntry[];
  ultrasounds: UltrasoundEntry[];
  consultations: ConsultationEntry[];
  delivery: DeliveryData;
  postpartum: PostpartumData;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  status: 'active' | 'monitored' | 'postpartum' | 'archived';
  createdAt: string;
  updatedAt: string;
}

// --- Navigation ---
export interface NavItem {
  label: string;
  icon: string;
  path: string;
  children?: NavItem[];
}

// --- Dashboard stats ---
export interface DashboardStats {
  totalPatients: number;
  newPatientsThisMonth: number;
  todayConsultations: number;
  upcomingAppointments: number;
  atRiskPatients: number;
  activeAlerts: number;
}

// --- Messages télémédecine ---
export interface TelemedicineMessage {
  id: string;
  patientId: string;
  patientName: string;
  type: 'glucose' | 'weight' | 'bp' | 'hypo' | 'file' | 'echo' | 'text';
  content: string;
  timestamp: string;
  read: boolean;
  attachments?: string[];
}

// --- Documents ---
export interface MedicalDocument {
  id: string;
  patientId: string;
  type: 'prescription' | 'lab_request' | 'echo_request' | 'certificate' | 'letter' | 'report';
  title: string;
  content: string;
  createdAt: string;
  signed: boolean;
}

// --- Utilisateur ---
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'doctor' | 'assistant' | 'admin';
  avatar?: string;
}
