import { useStore } from '@/store/useStore';
import {
  LayoutDashboard,
  Users,
  Activity,
  Baby,
  Microscope,
  FileText,
  MessageSquare,
  Settings,
  ChevronLeft,
  ChevronRight,
  Stethoscope,
  Shield,
} from 'lucide-react';

const navItems = [
  { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard, path: '/' },
  { id: 'patients', label: 'Patientes', icon: Users, path: '/patients' },
  { id: 'diabetes', label: 'Diabète', icon: Activity, path: '/diabetes', children: [
    { id: 'glycemic-cycle', label: 'Cycle glycémique', icon: Activity, path: '/glycemic' },
    { id: 'biology', label: 'Biologie', icon: Microscope, path: '/biology' },
  ]},
  { id: 'pregnancy', label: 'Grossesse', icon: Baby, path: '/pregnancy', children: [
    { id: 'echography', label: 'Échographie', icon: Baby, path: '/echography' },
  ]},
  { id: 'telemedicine', label: 'Télémédecine', icon: MessageSquare, path: '/telemedicine' },
  { id: 'documents', label: 'Documents', icon: FileText, path: '/documents' },
  { id: 'settings', label: 'Paramètres', icon: Settings, path: '/settings' },
];

export default function Sidebar() {
  const { sidebarCollapsed, toggleSidebar, currentPage, setCurrentPage, isAuthenticated, patients, selectedPatientId } = useStore();

  if (!isAuthenticated) return null;

  const selectedPatient = patients.find(p => p.id === selectedPatientId);

  return (
    <aside
      className={`fixed left-0 top-0 h-full bg-[#F8F9FA] border-r border-[#E5E7EB] flex flex-col transition-all duration-200 z-40 ${
        sidebarCollapsed ? 'w-[64px]' : 'w-[260px]'
      }`}
    >
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-[#2C5F7C] flex items-center justify-center flex-shrink-0">
            <Stethoscope className="w-4 h-4 text-white" />
          </div>
          {!sidebarCollapsed && (
            <div className="overflow-hidden">
              <h1 className="text-sm font-bold text-[#1A1D1F] truncate">DiabeGest</h1>
              <p className="text-[10px] text-[#6B7280] truncate">Grossesses diabétiques</p>
            </div>
          )}
        </div>
        <button
          onClick={toggleSidebar}
          className="ml-auto p-1 rounded hover:bg-[#E5E7EB] transition-colors flex-shrink-0"
        >
          {sidebarCollapsed ? <ChevronRight className="w-4 h-4 text-[#6B7280]" /> : <ChevronLeft className="w-4 h-4 text-[#6B7280]" />}
        </button>
      </div>

      {/* Patient info banner */}
      {selectedPatient && !sidebarCollapsed && (
        <div className="mx-3 mt-3 p-3 rounded-md bg-[#2C5F7C]/10 border border-[#2C5F7C]/20">
          <p className="text-[10px] text-[#6B7280] uppercase tracking-wider">Patient active</p>
          <p className="text-sm font-semibold text-[#2C5F7C] truncate">{selectedPatient.identity.firstName} {selectedPatient.identity.lastName}</p>
          <p className="text-xs text-[#6B7280]">
            {selectedPatient.pregnancy.sa ? `${selectedPatient.pregnancy.sa} SA` : 'N/A'}
            {' · '}
            {selectedPatient.diabetes.type === 'dg' ? 'DG' : selectedPatient.diabetes.type === 'dt1' ? 'DT1' : 'DT2'}
          </p>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 py-3 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id || item.children?.some(c => c.id === currentPage);

          return (
            <div key={item.id}>
              <button
                onClick={() => setCurrentPage(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors relative ${
                  isActive
                    ? 'bg-[#E8ECEF] text-[#1A1D1F] font-semibold'
                    : 'text-[#6B7280] hover:bg-[#F0F2F5] hover:text-[#1A1D1F]'
                } ${sidebarCollapsed ? 'justify-center px-2' : ''}`}
              >
                {isActive && (
                  <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-[#2C5F7C]" />
                )}
                <Icon className="w-[18px] h-[18px] flex-shrink-0" />
                {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
              </button>
              {!sidebarCollapsed && item.children && isActive && (
                <div className="ml-4 border-l border-[#E5E7EB]">
                  {item.children.map(child => {
                    const ChildIcon = child.icon;
                    const isChildActive = currentPage === child.id;
                    return (
                      <button
                        key={child.id}
                        onClick={() => setCurrentPage(child.id)}
                        className={`w-full flex items-center gap-3 pl-8 pr-4 py-2 text-sm transition-colors ${
                          isChildActive
                            ? 'text-[#2C5F7C] font-semibold'
                            : 'text-[#6B7280] hover:text-[#1A1D1F]'
                        }`}
                      >
                        <ChildIcon className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{child.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-[#E5E7EB]">
        {!sidebarCollapsed ? (
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#10B981]" />
            <span className="text-xs text-[#6B7280]">Sécurisé · RGPD</span>
          </div>
        ) : (
          <Shield className="w-4 h-4 text-[#10B981] mx-auto" />
        )}
      </div>
    </aside>
  );
}
