import { useStore } from '@/store/useStore';
import { Search, Bell, LogOut, User } from 'lucide-react';

const pageTitles: Record<string, string> = {
  dashboard: 'Tableau de bord',
  patients: 'Liste des patientes',
  'glycemic-cycle': 'Cycle glycémique',
  diabetes: 'Suivi du diabète',
  biology: 'Biologie',
  pregnancy: 'Grossesse',
  echography: 'Échographie obstétricale',
  telemedicine: 'Télémédecine',
  documents: 'Documents',
  settings: 'Paramètres',
};

export default function TopBar() {
  const { user, logout, currentPage, searchQuery, setSearchQuery, isAuthenticated } = useStore();

  if (!isAuthenticated) return null;

  const showSearch = currentPage === 'patients' || currentPage === 'dashboard';

  return (
    <header className="h-16 bg-white border-b border-[#E5E7EB] flex items-center justify-between px-6 sticky top-0 z-30">
      {/* Left: page title */}
      <div className="flex items-center gap-2">
        <h2 className="text-lg font-semibold text-[#1A1D1F]">{pageTitles[currentPage] || 'DiabeGest Pro'}</h2>
      </div>

      {/* Center: search */}
      {showSearch && (
        <div className="flex-1 max-w-md mx-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B7280]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher une patiente (nom, prénom, N° dossier)..."
              className="w-full h-9 pl-10 pr-4 rounded-md border border-[#E5E7EB] bg-[#F8F9FA] text-sm text-[#1A1D1F] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#2C5F7C] focus:ring-1 focus:ring-[#2C5F7C] transition-all"
            />
          </div>
        </div>
      )}

      {/* Right: actions */}
      <div className="flex items-center gap-3">
        <button className="relative p-2 rounded-lg hover:bg-[#F0F2F5] transition-colors">
          <Bell className="w-5 h-5 text-[#6B7280]" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-[#EF4444] rounded-full" />
        </button>

        <div className="h-6 w-px bg-[#E5E7EB]" />

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-[#2C5F7C] flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="hidden md:block">
            <p className="text-sm font-medium text-[#1A1D1F]">{user?.name || 'Dr. Utilisateur'}</p>
            <p className="text-xs text-[#6B7280]">{user?.role === 'doctor' ? 'Diabétologue' : user?.role}</p>
          </div>
        </div>

        <button onClick={logout} className="p-2 rounded-lg hover:bg-[#F0F2F5] transition-colors ml-1" title="Déconnexion">
          <LogOut className="w-4 h-4 text-[#6B7280]" />
        </button>
      </div>
    </header>
  );
}
