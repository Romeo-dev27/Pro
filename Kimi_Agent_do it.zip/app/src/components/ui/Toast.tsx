import { useStore } from '@/store/useStore';
import { X, CheckCircle, AlertCircle, AlertTriangle, Info } from 'lucide-react';
import { useEffect, useState } from 'react';

const iconMap = {
  success: CheckCircle,
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info,
};

const borderMap = {
  success: 'border-[#2C5F7C]',
  error: 'border-[#EF4444]',
  warning: 'border-[#F59E0B]',
  info: 'border-[#3B82F6]',
};

const textMap = {
  success: 'text-[#2C5F7C]',
  error: 'text-[#EF4444]',
  warning: 'text-[#F59E0B]',
  info: 'text-[#3B82F6]',
};

export default function ToastContainer() {
  const { toasts, removeToast } = useStore();
  const [visible, setVisible] = useState<string[]>([]);

  useEffect(() => {
    toasts.forEach(t => {
      if (!visible.includes(t.id)) {
        setTimeout(() => setVisible(prev => [...prev, t.id]), 50);
      }
    });
  }, [toasts, visible]);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-[100] flex flex-col gap-2 w-[360px]">
      {toasts.map(toast => {
        const Icon = iconMap[toast.type];
        const isVisible = visible.includes(toast.id);
        return (
          <div
            key={toast.id}
            className={`bg-white rounded-md border-l-4 ${borderMap[toast.type]} shadow-lg p-4 flex items-start gap-3 transition-all duration-300 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
            }`}
          >
            <Icon className={`w-5 h-5 ${textMap[toast.type]} flex-shrink-0 mt-0.5`} />
            <p className="text-sm text-[#1A1D1F] flex-1">{toast.message}</p>
            <button onClick={() => removeToast(toast.id)} className="p-0.5 hover:bg-[#F0F2F5] rounded transition-colors">
              <X className="w-4 h-4 text-[#6B7280]" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
