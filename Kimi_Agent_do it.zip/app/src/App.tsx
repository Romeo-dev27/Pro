import { useStore } from '@/store/useStore';
import Sidebar from '@/components/layout/Sidebar';
import TopBar from '@/components/layout/TopBar';
import ToastContainer from '@/components/ui/Toast';
import LoginPage from '@/pages/LoginPage';
import DashboardPage from '@/pages/DashboardPage';
import PatientsPage from '@/pages/PatientsPage';
import PatientDetailPage from '@/pages/PatientDetailPage';
import GlycemicCyclePage from '@/pages/GlycemicCyclePage';
import BiologyPage from '@/pages/BiologyPage';
import EchographyPage from '@/pages/EchographyPage';
import TelemedicinePage from '@/pages/TelemedicinePage';
import DocumentsPage from '@/pages/DocumentsPage';
import SettingsPage from '@/pages/SettingsPage';
import './App.css';

function AppContent() {
  const { isAuthenticated, currentPage, selectedPatientId } = useStore();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'patients':
        return selectedPatientId ? <PatientDetailPage /> : <PatientsPage />;
      case 'glycemic-cycle':
        return selectedPatientId ? <GlycemicCyclePage /> : <PatientsPage />;
      case 'diabetes':
        return selectedPatientId ? <GlycemicCyclePage /> : <PatientsPage />;
      case 'biology':
        return selectedPatientId ? <BiologyPage /> : <PatientsPage />;
      case 'pregnancy':
        return selectedPatientId ? <EchographyPage /> : <PatientsPage />;
      case 'echography':
        return selectedPatientId ? <EchographyPage /> : <PatientsPage />;
      case 'telemedicine':
        return <TelemedicinePage />;
      case 'documents':
        return selectedPatientId ? <DocumentsPage /> : <PatientsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Sidebar />
      <div
        className="transition-all duration-200"
        style={{ marginLeft: '260px' }}
      >
        <TopBar />
        <main className="p-6 min-h-[calc(100vh-64px)]">
          {renderPage()}
        </main>
      </div>
      <ToastContainer />
    </div>
  );
}

function App() {
  return <AppContent />;
}

export default App;
