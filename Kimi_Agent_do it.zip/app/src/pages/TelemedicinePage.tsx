import { useState } from 'react';
import { useStore } from '@/store/useStore';
import {
  MessageSquare, Send, CheckCheck, FileText,
  Activity, Weight, HeartPulse, AlertTriangle, Image
} from 'lucide-react';

const typeConfig = {
  glucose: { icon: Activity, color: '#2C5F7C', label: 'Glycémie' },
  weight: { icon: Weight, color: '#10B981', label: 'Poids' },
  bp: { icon: HeartPulse, color: '#EF4444', label: 'Tension' },
  hypo: { icon: AlertTriangle, color: '#F59E0B', label: 'Hypoglycémie' },
  file: { icon: FileText, color: '#6B7280', label: 'Document' },
  echo: { icon: Image, color: '#8B5CF6', label: 'Échographie' },
  text: { icon: MessageSquare, color: '#3B82F6', label: 'Message' },
};

export default function TelemedicinePage() {
  const { messages, markMessageRead, selectPatient, setCurrentPage } = useStore();
  const [replyText, setReplyText] = useState('');
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null);

  const unreadCount = messages.filter(m => !m.read).length;

  const handleSelectMessage = (id: string) => {
    setSelectedMessageId(id);
    markMessageRead(id);
  };

  const handleReply = () => {
    if (!replyText.trim()) return;
    setReplyText('');
    // In real app, would send reply
  };

  const handleViewPatient = (patientId: string) => {
    selectPatient(patientId);
    setCurrentPage('patients');
  };

  const selectedMessage = messages.find(m => m.id === selectedMessageId);

  return (
    <div className="h-[calc(100vh-140px)] bg-white rounded-md border border-[#E5E7EB] flex">
      {/* Left panel - message list */}
      <div className="w-[360px] border-r border-[#E5E7EB] flex flex-col">
        <div className="p-4 border-b border-[#E5E7EB]">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-[#1A1D1F]">Messages</h3>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-[#EF4444]/10 text-[#EF4444] text-xs font-medium">{unreadCount} non lu{unreadCount > 1 ? 's' : ''}</span>
            )}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {messages.map(msg => {
            const config = typeConfig[msg.type];
            const Icon = config.icon;
            return (
              <button
                key={msg.id}
                onClick={() => handleSelectMessage(msg.id)}
                className={`w-full text-left p-4 border-b border-[#F0F0F0] hover:bg-[#F6F7F9] transition-colors ${
                  selectedMessageId === msg.id ? 'bg-[#2C5F7C]/5 border-l-[3px] border-l-[#2C5F7C]' : ''
                } ${!msg.read ? 'bg-[#F8F9FA]' : ''}`}
              >
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${config.color}15` }}>
                    <Icon className="w-4 h-4" style={{ color: config.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className={`text-sm truncate ${!msg.read ? 'font-semibold text-[#1A1D1F]' : 'text-[#1A1D1F]'}`}>{msg.patientName}</p>
                      {!msg.read && <span className="w-2 h-2 rounded-full bg-[#2C5F7C] flex-shrink-0" />}
                    </div>
                    <p className="text-xs text-[#6B7280] truncate mt-0.5">{config.label} · {msg.content}</p>
                    <p className="text-[10px] text-[#9CA3AF] mt-1">{new Date(msg.timestamp).toLocaleString('fr-FR')}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Right panel - message detail */}
      <div className="flex-1 flex flex-col">
        {selectedMessage ? (
          <>
            <div className="p-4 border-b border-[#E5E7EB] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#2C5F7C]/10 flex items-center justify-center text-sm font-semibold text-[#2C5F7C]">
                  {selectedMessage.patientName.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#1A1D1F]">{selectedMessage.patientName}</p>
                  <p className="text-xs text-[#6B7280]">{typeConfig[selectedMessage.type].label}</p>
                </div>
              </div>
              <button
                onClick={() => handleViewPatient(selectedMessage.patientId)}
                className="h-8 px-3 bg-[#2C5F7C]/5 hover:bg-[#2C5F7C]/10 text-[#2C5F7C] text-xs font-medium rounded-md transition-colors"
              >
                Voir dossier
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* Patient message */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-[#F59E0B]/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-semibold text-[#F59E0B]">P</span>
                </div>
                <div className="bg-[#F8F9FA] rounded-lg rounded-tl-none p-4 max-w-md">
                  <div className="flex items-center gap-2 mb-2">
                    {(() => { const Icon = typeConfig[selectedMessage.type].icon; return <Icon className="w-4 h-4" style={{ color: typeConfig[selectedMessage.type].color }} />; })()}
                    <span className="text-xs font-medium" style={{ color: typeConfig[selectedMessage.type].color }}>{typeConfig[selectedMessage.type].label}</span>
                  </div>
                  <p className="text-sm text-[#1A1D1F]">{selectedMessage.content}</p>
                  <p className="text-[10px] text-[#9CA3AF] mt-2">{new Date(selectedMessage.timestamp).toLocaleString('fr-FR')}</p>
                </div>
              </div>

              {/* Read indicator */}
              <div className="flex items-center gap-1 ml-11">
                <CheckCheck className="w-3 h-3 text-[#10B981]" />
                <span className="text-[10px] text-[#9CA3AF]">Lu</span>
              </div>
            </div>

            {/* Reply area */}
            <div className="p-4 border-t border-[#E5E7EB]">
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleReply()}
                  placeholder="Répondre à la patiente..."
                  className="flex-1 h-10 px-4 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]"
                />
                <button
                  onClick={handleReply}
                  className="h-10 px-4 bg-[#2C5F7C] hover:bg-[#1E445A] text-white rounded-md transition-colors flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageSquare className="w-12 h-12 text-[#E5E7EB] mx-auto mb-3" />
              <p className="text-[#6B7280] text-sm">Sélectionnez un message pour voir les détails</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
