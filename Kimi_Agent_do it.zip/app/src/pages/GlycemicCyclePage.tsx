import { useState, useMemo } from 'react';
import { useStore } from '@/store/useStore';
import { mockGlycemicEntries } from '@/store/mockData';
import type { GlycemicTimePoint, GlycemicEntry } from '@/types';
import {
  ArrowLeft, TrendingUp, TrendingDown, Target, AlertTriangle,
  Plus, Printer, Calendar
} from 'lucide-react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Legend
} from 'recharts';

const timePointLabels: Record<GlycemicTimePoint, string> = {
  beforeBreakfast: 'Avant petit-déjeuner',
  afterBreakfast: 'Après petit-déjeuner',
  beforeLunch: 'Avant déjeuner',
  afterLunch: 'Après déjeuner',
  beforeDinner: 'Avant dîner',
  afterDinner: 'Après dîner',
  nighttime: 'Nocturne',
};

const timePointOrder: GlycemicTimePoint[] = [
  'beforeBreakfast', 'afterBreakfast', 'beforeLunch', 'afterLunch',
  'beforeDinner', 'afterDinner', 'nighttime',
];

// Objectifs glycémiques grossesse (g/L * 100 = mg/dL)
const GLUCOSE_TARGET_MIN = 60;  // 0.60 g/L
const GLUCOSE_TARGET_MAX = 120; // 1.20 g/L
const GLUCOSE_FASTING_MAX = 95;  // 0.95 g/L
const GLUCOSE_POSTPRANDIAL_MAX = 140; // 1.40 g/L

export default function GlycemicCyclePage() {
  const { selectedPatient, selectPatient, setCurrentPage, addGlycemicEntry, addToast } = useStore();
  const [selectedDate, setSelectedDate] = useState('2025-04-14');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newEntry, setNewEntry] = useState({ timePoint: 'beforeBreakfast' as GlycemicTimePoint, value: '', notes: '' });

  if (!selectedPatient) {
    return (
      <div className="text-center py-20">
        <p className="text-[#6B7280]">Sélectionnez une patiente pour voir son cycle glycémique</p>
        <button onClick={() => setCurrentPage('patients')} className="mt-4 px-4 py-2 bg-[#2C5F7C] text-white rounded-md text-sm">Voir la liste</button>
      </div>
    );
  }

  const p = selectedPatient;

  // Get entries for this patient
  const patientEntries = useMemo(() => {
    return mockGlycemicEntries.filter(e => e.patientId === p.id);
  }, [p.id]);

  // Chart data: group by date, show all time points
  const chartData = useMemo(() => {
    const dateMap = new Map<string, Record<string, number | null>>();
    patientEntries.forEach(entry => {
      if (!dateMap.has(entry.date)) {
        dateMap.set(entry.date, {});
      }
      dateMap.get(entry.date)![entry.timePoint] = entry.value;
    });

    return Array.from(dateMap.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-7) // last 7 days
      .map(([date, values]) => {
        const point: Record<string, unknown> = { date: date.slice(5) }; // MM-DD
        timePointOrder.forEach(tp => {
          point[tp] = values[tp] || null;
        });
        return point;
      });
  }, [patientEntries]);

  // Stats for selected date
  const dayEntries = patientEntries.filter(e => e.date === selectedDate);
  const dayValues = dayEntries.map(e => e.value).filter(v => v > 0);
  const dayAvg = dayValues.length > 0 ? Math.round(dayValues.reduce((a, b) => a + b, 0) / dayValues.length) : null;
  const inTarget = dayValues.filter(v => v >= GLUCOSE_TARGET_MIN && v <= GLUCOSE_TARGET_MAX).length;
  const inTargetPct = dayValues.length > 0 ? Math.round((inTarget / dayValues.length) * 100) : 0;
  const hyperCount = dayValues.filter(v => v > GLUCOSE_TARGET_MAX).length;
  const hypoCount = dayValues.filter(v => v < GLUCOSE_TARGET_MIN).length;

  const handleAddEntry = () => {
    if (!newEntry.value) return;
    const entry: GlycemicEntry = {
      id: `ge-${Date.now()}`,
      patientId: p.id,
      date: selectedDate,
      timePoint: newEntry.timePoint,
      value: parseInt(newEntry.value),
      notes: newEntry.notes,
      createdAt: new Date().toISOString(),
    };
    addGlycemicEntry(entry);
    setNewEntry({ timePoint: 'beforeBreakfast', value: '', notes: '' });
    setShowAddForm(false);
    addToast('Glycémie enregistrée', 'success');
  };

  const getValueColor = (value: number, timePoint: GlycemicTimePoint) => {
    if (value < GLUCOSE_TARGET_MIN) return 'text-[#EF4444]';
    if (timePoint === 'beforeBreakfast' && value > GLUCOSE_FASTING_MAX) return 'text-[#EF4444]';
    if ((timePoint.includes('after') || timePoint === 'nighttime') && value > GLUCOSE_POSTPRANDIAL_MAX) return 'text-[#EF4444]';
    return 'text-[#10B981]';
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => selectPatient(null)} className="p-2 rounded-lg hover:bg-[#F0F2F5] transition-colors">
            <ArrowLeft className="w-5 h-5 text-[#6B7280]" />
          </button>
          <div>
            <h2 className="text-lg font-semibold text-[#1A1D1F]">Cycle glycémique — {p.identity.lastName} {p.identity.firstName}</h2>
            <p className="text-xs text-[#6B7280]">{p.pregnancy.sa} SA · {p.diabetes.type === 'dg' ? 'DG' : p.diabetes.type === 'dt1' ? 'DT1' : 'DT2'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => addToast('Impression en cours...', 'info')} className="h-9 px-3 border border-[#E5E7EB] hover:bg-[#F0F2F5] text-[#6B7280] text-sm rounded-md transition-colors flex items-center gap-2">
            <Printer className="w-4 h-4" /> Imprimer
          </button>
          <button onClick={() => setShowAddForm(!showAddForm)} className="h-9 px-4 bg-[#2C5F7C] hover:bg-[#1E445A] text-white text-sm font-medium rounded-md transition-colors flex items-center gap-2">
            <Plus className="w-4 h-4" /> Saisir une glycémie
          </button>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
          <div className="flex items-center gap-2 mb-1">
            <Target className="w-4 h-4 text-[#2C5F7C]" />
            <span className="text-xs text-[#6B7280]">Moyenne du jour</span>
          </div>
          <p className="text-2xl font-bold text-[#1A1D1F]">{dayAvg || '--'} <span className="text-sm font-normal text-[#6B7280]">mg/dL</span></p>
        </div>
        <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-[#10B981]" />
            <span className="text-xs text-[#6B7280]">Dans la cible</span>
          </div>
          <p className="text-2xl font-bold text-[#10B981]">{inTargetPct}%</p>
        </div>
        <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-4 h-4 text-[#EF4444]" />
            <span className="text-xs text-[#6B7280]">Hyperglycémies</span>
          </div>
          <p className="text-2xl font-bold text-[#EF4444]">{hyperCount}</p>
        </div>
        <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingDown className="w-4 h-4 text-[#F59E0B]" />
            <span className="text-xs text-[#6B7280]">Hypoglycémies</span>
          </div>
          <p className="text-2xl font-bold text-[#F59E0B]">{hypoCount}</p>
        </div>
      </div>

      {/* Add form */}
      {showAddForm && (
        <div className="bg-white rounded-md border border-[#2C5F7C]/30 p-5">
          <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Nouvelle mesure glycémique</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-[#6B7280] mb-1.5">Moment de la mesure</label>
              <select
                value={newEntry.timePoint}
                onChange={(e) => setNewEntry({ ...newEntry, timePoint: e.target.value as GlycemicTimePoint })}
                className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]"
              >
                {timePointOrder.map(tp => (
                  <option key={tp} value={tp}>{timePointLabels[tp]}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-[#6B7280] mb-1.5">Valeur (mg/dL)</label>
              <input
                type="number"
                value={newEntry.value}
                onChange={(e) => setNewEntry({ ...newEntry, value: e.target.value })}
                placeholder="Ex: 105"
                className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]"
              />
            </div>
            <div>
              <label className="block text-xs text-[#6B7280] mb-1.5">Notes (optionnel)</label>
              <input
                type="text"
                value={newEntry.notes}
                onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
                placeholder="Commentaire..."
                className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <button onClick={() => setShowAddForm(false)} className="h-9 px-4 border border-[#E5E7EB] hover:bg-[#F0F2F5] text-[#6B7280] text-sm rounded-md transition-colors">Annuler</button>
            <button onClick={handleAddEntry} className="h-9 px-4 bg-[#2C5F7C] hover:bg-[#1E445A] text-white text-sm font-medium rounded-md transition-colors">Enregistrer</button>
          </div>
        </div>
      )}

      {/* Chart */}
      <div className="bg-white rounded-md border border-[#E5E7EB] p-5">
        <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Évolution glycémique (7 derniers jours)</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
            <XAxis dataKey="date" tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} domain={[40, 220]} />
            <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid #E5E7EB', fontSize: '12px' }} />
            <ReferenceLine y={GLUCOSE_TARGET_MIN} stroke="#10B981" strokeDasharray="4 4" strokeWidth={1} />
            <ReferenceLine y={GLUCOSE_TARGET_MAX} stroke="#EF4444" strokeDasharray="4 4" strokeWidth={1} />
            <Legend wrapperStyle={{ fontSize: '12px' }} />
            <Line type="monotone" dataKey="beforeBreakfast" name="Avant PD" stroke="#2C5F7C" strokeWidth={2} dot={{ r: 3 }} connectNulls />
            <Line type="monotone" dataKey="afterBreakfast" name="Après PD" stroke="#3B82F6" strokeWidth={2} dot={{ r: 3 }} connectNulls />
            <Line type="monotone" dataKey="beforeLunch" name="Avant Déj" stroke="#10B981" strokeWidth={2} dot={{ r: 3 }} connectNulls />
            <Line type="monotone" dataKey="afterLunch" name="Après Déj" stroke="#F59E0B" strokeWidth={2} dot={{ r: 3 }} connectNulls />
            <Line type="monotone" dataKey="beforeDinner" name="Avant Dîn" stroke="#8B5CF6" strokeWidth={2} dot={{ r: 3 }} connectNulls />
            <Line type="monotone" dataKey="afterDinner" name="Après Dîn" stroke="#EC4899" strokeWidth={2} dot={{ r: 3 }} connectNulls />
          </LineChart>
        </ResponsiveContainer>
        <div className="flex items-center gap-4 mt-3 text-xs text-[#6B7280]">
          <span className="flex items-center gap-1.5">
            <span className="w-6 h-0 border-t border-dashed border-[#10B981]" /> Cible min (60)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-6 h-0 border-t border-dashed border-[#EF4444]" /> Cible max (120)
          </span>
        </div>
      </div>

      {/* Day detail table */}
      <div className="bg-white rounded-md border border-[#E5E7EB]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E7EB]">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#6B7280]" />
            <h3 className="text-sm font-semibold text-[#1A1D1F]">Détail du {new Date(selectedDate).toLocaleDateString('fr-FR')}</h3>
          </div>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="h-9 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]"
          />
        </div>
        <div className="grid grid-cols-7 divide-x divide-[#E5E7EB]">
          {timePointOrder.map(tp => {
            const entry = dayEntries.find(e => e.timePoint === tp);
            return (
              <div key={tp} className="p-4 text-center">
                <p className="text-[10px] text-[#6B7280] mb-2 uppercase">{timePointLabels[tp]}</p>
                {entry ? (
                  <>
                    <p className={`text-2xl font-bold ${getValueColor(entry.value, tp)}`}>{entry.value}</p>
                    <p className="text-[10px] text-[#9CA3AF]">mg/dL</p>
                    {entry.notes && <p className="text-[10px] text-[#6B7280] mt-1 italic">{entry.notes}</p>}
                  </>
                ) : (
                  <p className="text-lg text-[#E5E7EB]">—</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
