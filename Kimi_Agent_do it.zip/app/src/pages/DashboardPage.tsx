import { useStore } from '@/store/useStore';
import { getDashboardStats, getDiabetesTypeDistribution, getTrimesterDistribution, getMonthlyActivity } from '@/store/mockData';
import {
  Users, UserPlus, CalendarDays, AlertTriangle,
  ChevronRight, ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

const statCards = [
  { key: 'totalPatients', label: 'Patientes suivies', icon: Users, color: '#2C5F7C', trend: '+12%', trendUp: true },
  { key: 'newPatientsThisMonth', label: 'Nouvelles ce mois', icon: UserPlus, color: '#10B981', trend: '+3', trendUp: true },
  { key: 'todayConsultations', label: 'Consultations aujourd\'hui', icon: CalendarDays, color: '#3B82F6', trend: '+2', trendUp: true },
  { key: 'atRiskPatients', label: 'Patientes à risque', icon: AlertTriangle, color: '#EF4444', trend: '-1', trendUp: false },
];

export default function DashboardPage() {
  const { patients, setCurrentPage, selectPatient } = useStore();
  const stats = getDashboardStats();
  const diabetesDist = getDiabetesTypeDistribution();
  const trimesterDist = getTrimesterDistribution();
  const monthlyActivity = getMonthlyActivity();

  const recentPatients = [...patients]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 8);

  const handlePatientClick = (id: string) => {
    selectPatient(id);
    setCurrentPage('patients');
  };

  const getRiskBadge = (risk: string) => {
    const map: Record<string, string> = {
      low: 'bg-[#10B981]/10 text-[#10B981]',
      medium: 'bg-[#F59E0B]/10 text-[#F59E0B]',
      high: 'bg-[#EF4444]/10 text-[#EF4444]',
      critical: 'bg-[#EF4444]/20 text-[#EF4444]',
    };
    const labels: Record<string, string> = { low: 'Faible', medium: 'Modéré', high: 'Élevé', critical: 'Critique' };
    return <span className={`px-2 py-0.5 rounded text-xs font-medium ${map[risk]}`}>{labels[risk]}</span>;
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, string> = {
      active: 'bg-[#2C5F7C]/10 text-[#2C5F7C]',
      monitored: 'bg-[#F59E0B]/10 text-[#F59E0B]',
      postpartum: 'bg-[#10B981]/10 text-[#10B981]',
      archived: 'bg-[#6B7280]/10 text-[#6B7280]',
    };
    const labels: Record<string, string> = { active: 'Active', monitored: 'Surveillance', postpartum: 'Post-partum', archived: 'Archivée' };
    return <span className={`px-2 py-0.5 rounded text-xs font-medium ${map[status]}`}>{labels[status]}</span>;
  };

  return (
    <div className="space-y-6">
      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map(card => {
          const Icon = card.icon;
          const value = stats[card.key as keyof typeof stats];
          return (
            <div key={card.key} className="bg-white rounded-md border border-[#E5E7EB] p-5 hover:shadow-sm transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${card.color}15` }}>
                  <Icon className="w-5 h-5" style={{ color: card.color }} />
                </div>
                <div className={`flex items-center gap-0.5 text-xs font-medium ${card.trendUp ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                  {card.trendUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {card.trend}
                </div>
              </div>
              <p className="text-2xl font-bold text-[#1A1D1F]">{value}</p>
              <p className="text-xs text-[#6B7280] mt-0.5">{card.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Monthly activity */}
        <div className="lg:col-span-2 bg-white rounded-md border border-[#E5E7EB] p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-[#1A1D1F]">Activité mensuelle</h3>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#2C5F7C]" /> Consultations</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#10B981]" /> Nouvelles patientes</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyActivity}>
              <defs>
                <linearGradient id="colorConsultations" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2C5F7C" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#2C5F7C" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorNew" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ borderRadius: '6px', border: '1px solid #E5E7EB', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="consultations" stroke="#2C5F7C" strokeWidth={2} fill="url(#colorConsultations)" />
              <Area type="monotone" dataKey="newPatients" stroke="#10B981" strokeWidth={2} fill="url(#colorNew)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Distribution charts */}
        <div className="space-y-4">
          {/* Diabetes type */}
          <div className="bg-white rounded-md border border-[#E5E7EB] p-5">
            <h3 className="text-sm font-semibold text-[#1A1D1F] mb-3">Types de diabète</h3>
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={diabetesDist} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" stroke="none">
                  {diabetesDist.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid #E5E7EB', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-3 mt-1">
              {diabetesDist.map(d => (
                <span key={d.name} className="flex items-center gap-1 text-xs text-[#6B7280]">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }} /> {d.name}
                </span>
              ))}
            </div>
          </div>

          {/* Trimester */}
          <div className="bg-white rounded-md border border-[#E5E7EB] p-5">
            <h3 className="text-sm font-semibold text-[#1A1D1F] mb-3">Répartition par trimestre</h3>
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={trimesterDist} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" stroke="none">
                  {trimesterDist.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid #E5E7EB', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-3 mt-1">
              {trimesterDist.map(d => (
                <span key={d.name} className="flex items-center gap-1 text-xs text-[#6B7280]">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }} /> {d.name}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent patients table */}
      <div className="bg-white rounded-md border border-[#E5E7EB]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E7EB]">
          <h3 className="text-sm font-semibold text-[#1A1D1F]">Patientes récentes</h3>
          <button
            onClick={() => setCurrentPage('patients')}
            className="flex items-center gap-1 text-xs text-[#2C5F7C] hover:text-[#1E445A] font-medium"
          >
            Voir tout <ChevronRight className="w-3 h-3" />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB]">
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Patient</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Âge / Geste</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Grossesse</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Diabète</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Risque</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Statut</th>
                <th className="px-5 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {recentPatients.map(patient => (
                <tr
                  key={patient.id}
                  onClick={() => handlePatientClick(patient.id)}
                  className="border-b border-[#E5E7EB] hover:bg-[#F6F7F9] cursor-pointer transition-colors"
                >
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#2C5F7C]/10 flex items-center justify-center text-xs font-semibold text-[#2C5F7C]">
                        {patient.identity.firstName[0]}{patient.identity.lastName[0]}
                      </div>
                      <div>
                        <p className="font-medium text-[#1A1D1F]">{patient.identity.lastName} {patient.identity.firstName}</p>
                        <p className="text-xs text-[#6B7280]">{patient.identity.fileNumber}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-[#6B7280]">{patient.identity.age} ans / G{patient.obstetricHistory.geste}P{patient.obstetricHistory.parite}</td>
                  <td className="px-5 py-3 text-[#6B7280]">
                    {patient.pregnancy.sa ? `${patient.pregnancy.sa} SA` : 'N/A'}
                    {patient.pregnancy.trimester ? ` (T${patient.pregnancy.trimester})` : ''}
                  </td>
                  <td className="px-5 py-3">
                    <span className="text-xs">
                      {patient.diabetes.type === 'dg' ? 'DG' : patient.diabetes.type === 'dt1' ? 'DT1' : patient.diabetes.type === 'dt2' ? 'DT2' : 'Autre'}
                    </span>
                  </td>
                  <td className="px-5 py-3">{getRiskBadge(patient.riskLevel)}</td>
                  <td className="px-5 py-3">{getStatusBadge(patient.status)}</td>
                  <td className="px-5 py-3">
                    <ChevronRight className="w-4 h-4 text-[#9CA3AF]" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Alerts section */}
      <div className="bg-white rounded-md border border-[#E5E7EB] p-5">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-4 h-4 text-[#EF4444]" />
          <h3 className="text-sm font-semibold text-[#1A1D1F]">Alertes médicales actives</h3>
          <span className="ml-auto px-2 py-0.5 rounded-full bg-[#EF4444]/10 text-[#EF4444] text-xs font-medium">{stats.activeAlerts}</span>
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-3 rounded-md bg-[#EF4444]/5 border border-[#EF4444]/20">
            <div className="w-2 h-2 rounded-full bg-[#EF4444] mt-1.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-[#1A1D1F]"><strong>Lyna Boudraa</strong> — Hyperglycémie sévère post-prandiale (1.95 g/L)</p>
              <p className="text-xs text-[#6B7280] mt-0.5">15 avril 2025 · Insulinothérapie à ajuster</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-md bg-[#F59E0B]/5 border border-[#F59E0B]/20">
            <div className="w-2 h-2 rounded-full bg-[#F59E0B] mt-1.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-[#1A1D1F]"><strong>Fatiha Zerrouki</strong> — Tension artérielle élevée (138/90 mmHg)</p>
              <p className="text-xs text-[#6B7280] mt-0.5">14 avril 2025 · Surveillance rapprochée recommandée</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-md bg-[#F59E0B]/5 border border-[#F59E0B]/20">
            <div className="w-2 h-2 rounded-full bg-[#F59E0B] mt-1.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-[#1A1D1F]"><strong>Aïcha Sahnoun</strong> — Pré-éclampsie historique + obésité morbide</p>
              <p className="text-xs text-[#6B7280] mt-0.5">Grossesse à très haut risque · Protéinurie à contrôler</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-md bg-[#2C5F7C]/5 border border-[#2C5F7C]/20">
            <div className="w-2 h-2 rounded-full bg-[#2C5F7C] mt-1.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-[#1A1D1F]"><strong>Soraya Amara</strong> — DT1 depuis 26 ans, pompe à insuline</p>
              <p className="text-xs text-[#6B7280] mt-0.5">Boucle fermée hybride · Contrôle optimal</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
