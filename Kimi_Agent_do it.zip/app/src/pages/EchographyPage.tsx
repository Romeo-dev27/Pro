import { useMemo } from 'react';
import { useStore } from '@/store/useStore';
import { mockUltrasounds } from '@/store/mockData';
import { ArrowLeft, Baby, TrendingUp, AlertTriangle } from 'lucide-react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer
} from 'recharts';

export default function EchographyPage() {
  const { selectedPatient, selectPatient, setCurrentPage } = useStore();

  if (!selectedPatient) {
    return (
      <div className="text-center py-20">
        <p className="text-[#6B7280]">Sélectionnez une patiente pour voir ses échographies</p>
        <button onClick={() => setCurrentPage('patients')} className="mt-4 px-4 py-2 bg-[#2C5F7C] text-white rounded-md text-sm">Voir la liste</button>
      </div>
    );
  }

  const p = selectedPatient;
  const ultrasounds = useMemo(() =>
    mockUltrasounds
      .filter(u => u.patientId === p.id)
      .sort((a, b) => a.date.localeCompare(b.date)),
    [p.id]
  );

  const lastUltrasound = ultrasounds[ultrasounds.length - 1];

  // Chart data for fetal growth
  const growthData = ultrasounds.map(u => ({
    sa: u.gestationalAgeAtExam,
    poids: u.estimatedFetalWeight ? Math.round(u.estimatedFetalWeight) : null,
    percentile: u.percentile,
  })).filter(d => d.poids !== null);

  const getPercentileColor = (p: number | null) => {
    if (p === null) return 'text-[#6B7280]';
    if (p < 10 || p > 90) return 'text-[#EF4444]';
    if (p < 25 || p > 75) return 'text-[#F59E0B]';
    return 'text-[#10B981]';
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => selectPatient(null)} className="p-2 rounded-lg hover:bg-[#F0F2F5] transition-colors">
          <ArrowLeft className="w-5 h-5 text-[#6B7280]" />
        </button>
        <div>
          <h2 className="text-lg font-semibold text-[#1A1D1F]">Échographie — {p.identity.lastName} {p.identity.firstName}</h2>
          <p className="text-xs text-[#6B7280]">{ultrasounds.length} échographie{ultrasounds.length > 1 ? 's' : ''} enregistrée{ultrasounds.length > 1 ? 's' : ''}</p>
        </div>
      </div>

      {lastUltrasound && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
            <p className="text-xs text-[#6B7280]">Poids fœtal estimé</p>
            <p className="text-2xl font-bold text-[#1A1D1F]">{lastUltrasound.estimatedFetalWeight} <span className="text-sm font-normal text-[#6B7280]">g</span></p>
          </div>
          <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
            <p className="text-xs text-[#6B7280]">Percentile</p>
            <p className={`text-2xl font-bold ${getPercentileColor(lastUltrasound.percentile)}`}>{lastUltrasound.percentile}<span className="text-sm font-normal text-[#6B7280]">e</span></p>
          </div>
          <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
            <p className="text-xs text-[#6B7280]">Âge gestationnel</p>
            <p className="text-2xl font-bold text-[#2C5F7C]">{lastUltrasound.gestationalAgeAtExam} <span className="text-sm font-normal text-[#6B7280]">SA</span></p>
          </div>
          <div className="bg-white rounded-md border border-[#E5E7EB] p-4">
            <p className="text-xs text-[#6B7280]">Liquide amniotique</p>
            <p className="text-lg font-bold text-[#10B981]">{lastUltrasound.amnioticFluid}</p>
          </div>
        </div>
      )}

      {/* Growth curve */}
      {growthData.length > 0 && (
        <div className="bg-white rounded-md border border-[#E5E7EB] p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-[#2C5F7C]" />
            <h3 className="text-sm font-semibold text-[#1A1D1F]">Courbe de croissance fœtale</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={growthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="sa" tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} label={{ value: 'SA', position: 'insideBottom', offset: -5, style: { fontSize: 12, fill: '#6B7280' } }} />
              <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} label={{ value: 'Poids (g)', angle: -90, position: 'insideLeft', style: { fontSize: 12, fill: '#6B7280' } }} />
              <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid #E5E7EB', fontSize: '12px' }} />
              <Line type="monotone" dataKey="poids" stroke="#2C5F7C" strokeWidth={3} dot={{ r: 5, fill: '#2C5F7C' }} name="Poids fœtal (g)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Ultrasound details */}
      <div className="space-y-3">
        {ultrasounds.map(us => (
          <div key={us.id} className="bg-white rounded-md border border-[#E5E7EB] p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#2C5F7C]/10 flex items-center justify-center">
                  <Baby className="w-5 h-5 text-[#2C5F7C]" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#1A1D1F]">{new Date(us.date).toLocaleDateString('fr-FR')}</p>
                  <p className="text-xs text-[#6B7280]">{us.gestationalAgeAtExam} SA · Présentation: {us.presentation}</p>
                </div>
              </div>
              <div className={`px-3 py-1 rounded text-xs font-medium ${getPercentileColor(us.percentile)} bg-opacity-10`}>
                {us.percentile}e percentile
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <EchoField label="BIP" value={us.bpd ? `${us.bpd} mm` : 'N/A'} />
              <EchoField label="PC" value={us.hc ? `${us.hc} mm` : 'N/A'} />
              <EchoField label="PA" value={us.ac ? `${us.ac} mm` : 'N/A'} />
              <EchoField label="LF" value={us.fl ? `${us.fl} mm` : 'N/A'} />
              <EchoField label="Poids estimé" value={us.estimatedFetalWeight ? `${us.estimatedFetalWeight} g` : 'N/A'} highlight />
              <EchoField label="Percentile" value={us.percentile ? `${us.percentile}e` : 'N/A'} />
              <EchoField label="Liquide amniotique" value={us.amnioticFluid || 'N/A'} />
              <EchoField label="Doppler" value={us.doppler || 'N/A'} />
            </div>

            {/* Alerts */}
            {us.percentile && (us.percentile < 10 || us.percentile > 90) && (
              <div className="mt-4 p-3 rounded-md bg-[#EF4444]/5 border border-[#EF4444]/20 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-[#EF4444] mt-0.5 flex-shrink-0" />
                <p className="text-xs text-[#EF4444]">
                  {us.percentile < 10
                    ? 'Risque de retard de croissance intra-utérin (RCIU) — surveillance rapprochée recommandée'
                    : 'Risque de macrosomie — envisager une évaluation du mode d\'accouchement'}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      {ultrasounds.length === 0 && (
        <div className="text-center py-16 bg-white rounded-md border border-[#E5E7EB]">
          <Baby className="w-12 h-12 text-[#E5E7EB] mx-auto mb-3" />
          <p className="text-[#6B7280]">Aucune échographie enregistrée pour cette patiente</p>
        </div>
      )}
    </div>
  );
}

function EchoField({ label, value, highlight = false }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="p-3 rounded-md bg-[#F8F9FA]">
      <p className="text-[10px] text-[#6B7280] uppercase">{label}</p>
      <p className={`text-sm font-medium ${highlight ? 'text-[#2C5F7C]' : 'text-[#1A1D1F]'}`}>{value}</p>
    </div>
  );
}
