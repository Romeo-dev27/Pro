import { useState } from 'react';
import { useStore } from '@/store/useStore';
import {
  ArrowLeft, User, Ruler, Heart, Baby, Activity, ClipboardList,
  FileText, Pencil, Save, X
} from 'lucide-react';

type TabId = 'identity' | 'anthropometrics' | 'history' | 'pregnancy' | 'diabetes' | 'consultations';

const tabs: { id: TabId; label: string; icon: typeof User }[] = [
  { id: 'identity', label: 'Identité', icon: User },
  { id: 'anthropometrics', label: 'Anthropométrie', icon: Ruler },
  { id: 'history', label: 'Antécédents', icon: ClipboardList },
  { id: 'pregnancy', label: 'Grossesse', icon: Baby },
  { id: 'diabetes', label: 'Diabète', icon: Activity },
  { id: 'consultations', label: 'Consultations', icon: FileText },
];

export default function PatientDetailPage() {
  const { selectedPatient, selectPatient, setCurrentPage, updatePatient, addToast } = useStore();
  const [activeTab, setActiveTab] = useState<TabId>('identity');
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState<Record<string, unknown>>({});

  if (!selectedPatient) {
    return (
      <div className="text-center py-20">
        <p className="text-[#6B7280]">Sélectionnez une patiente pour voir les détails</p>
        <button
          onClick={() => setCurrentPage('patients')}
          className="mt-4 px-4 py-2 bg-[#2C5F7C] text-white rounded-md text-sm"
        >
          Voir la liste
        </button>
      </div>
    );
  }

  const p = selectedPatient;

  const handleBack = () => {
    selectPatient(null);
  };

  const handleEdit = () => {
    setEditMode(true);
    setEditData({ ...p });
  };

  const handleSave = () => {
    updatePatient(p.id, editData);
    setEditMode(false);
    addToast('Modifications enregistrées', 'success');
  };

  const handleCancel = () => {
    setEditMode(false);
    setEditData({});
  };

  const getRiskBadge = (risk: string) => {
    const map: Record<string, string> = {
      low: 'bg-[#10B981]/10 text-[#10B981]',
      medium: 'bg-[#F59E0B]/10 text-[#F59E0B]',
      high: 'bg-[#EF4444]/10 text-[#EF4444]',
      critical: 'bg-[#EF4444]/20 text-[#EF4444]',
    };
    const labels: Record<string, string> = { low: 'Faible', medium: 'Modéré', high: 'Élevé', critical: 'Critique' };
    return <span className={`px-2.5 py-1 rounded text-xs font-medium ${map[risk]}`}>{labels[risk]}</span>;
  };

  return (
    <div className="space-y-4">
      {/* Patient banner */}
      <div className="bg-white rounded-md border border-[#E5E7EB] p-5">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={handleBack}
              className="p-2 rounded-lg hover:bg-[#F0F2F5] transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div className="w-14 h-14 rounded-full bg-[#2C5F7C]/10 flex items-center justify-center text-lg font-bold text-[#2C5F7C]">
              {p.identity.firstName[0]}{p.identity.lastName[0]}
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#1A1D1F]">{p.identity.lastName} {p.identity.firstName}</h2>
              <div className="flex items-center gap-3 mt-1 text-sm text-[#6B7280]">
                <span>{p.identity.age} ans</span>
                <span>·</span>
                <span>{p.identity.fileNumber}</span>
                <span>·</span>
                <span>{p.identity.phone}</span>
                <span>·</span>
                {p.pregnancy.sa ? (
                  <span className="text-[#2C5F7C] font-medium">{p.pregnancy.sa} SA (T{p.pregnancy.trimester}) · DPA: {p.pregnancy.dpa}</span>
                ) : (
                  <span>Grossesse non déclarée</span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {getRiskBadge(p.riskLevel)}
            {editMode ? (
              <>
                <button onClick={handleSave} className="h-9 px-4 bg-[#10B981] hover:bg-[#059669] text-white text-sm font-medium rounded-md transition-colors flex items-center gap-2">
                  <Save className="w-4 h-4" /> Enregistrer
                </button>
                <button onClick={handleCancel} className="h-9 px-4 border border-[#E5E7EB] hover:bg-[#F0F2F5] text-[#6B7280] text-sm font-medium rounded-md transition-colors flex items-center gap-2">
                  <X className="w-4 h-4" /> Annuler
                </button>
              </>
            ) : (
              <button onClick={handleEdit} className="h-9 px-4 bg-[#2C5F7C] hover:bg-[#1E445A] text-white text-sm font-medium rounded-md transition-colors flex items-center gap-2">
                <Pencil className="w-4 h-4" /> Modifier
              </button>
            )}
          </div>
        </div>

        {/* Quick actions */}
        <div className="flex items-center gap-2 mt-4 pt-4 border-t border-[#E5E7EB]">
          <button onClick={() => setCurrentPage('glycemic-cycle')} className="h-8 px-3 bg-[#2C5F7C]/5 hover:bg-[#2C5F7C]/10 text-[#2C5F7C] text-xs font-medium rounded-md transition-colors flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5" /> Cycle glycémique
          </button>
          <button onClick={() => setCurrentPage('biology')} className="h-8 px-3 bg-[#2C5F7C]/5 hover:bg-[#2C5F7C]/10 text-[#2C5F7C] text-xs font-medium rounded-md transition-colors flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" /> Biologie
          </button>
          <button onClick={() => setCurrentPage('echography')} className="h-8 px-3 bg-[#2C5F7C]/5 hover:bg-[#2C5F7C]/10 text-[#2C5F7C] text-xs font-medium rounded-md transition-colors flex items-center gap-1.5">
            <Baby className="w-3.5 h-3.5" /> Échographie
          </button>
          <button onClick={() => setCurrentPage('documents')} className="h-8 px-3 bg-[#2C5F7C]/5 hover:bg-[#2C5F7C]/10 text-[#2C5F7C] text-xs font-medium rounded-md transition-colors flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" /> Documents
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#E5E7EB] overflow-x-auto">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-[#2C5F7C] text-[#2C5F7C]'
                  : 'border-transparent text-[#6B7280] hover:text-[#1A1D1F]'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="bg-white rounded-md border border-[#E5E7EB] p-6">
        {/* === IDENTITY TAB === */}
        {activeTab === 'identity' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Informations administratives</h3>
              <div className="space-y-3">
                <Field label="Nom" value={p.identity.lastName} />
                <Field label="Prénom" value={p.identity.firstName} />
                <Field label="Date de naissance" value={new Date(p.identity.birthDate).toLocaleDateString('fr-FR')} />
                <Field label="Âge" value={`${p.identity.age} ans`} />
                <Field label="Téléphone" value={p.identity.phone} />
                <Field label="Adresse" value={p.identity.address} />
                <Field label="Profession" value={p.identity.profession} />
                <Field label="Assurance" value={p.identity.insurance} />
                <Field label="N° Dossier" value={p.identity.fileNumber} />
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Constantes vitales</h3>
              <div className="space-y-3">
                <Field label="Pression artérielle" value={`${p.vitals.bloodPressure} mmHg`} />
                <Field label="Fréquence cardiaque" value={`${p.vitals.heartRate} bpm`} />
                <Field label="Température" value={`${p.vitals.temperature} °C`} />
                <Field label="Saturation O₂" value={`${p.vitals.oxygenSaturation}%`} />
              </div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mt-8 mb-4 uppercase tracking-wider">Classification</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between py-2 border-b border-[#F0F0F0]">
                  <span className="text-sm text-[#6B7280]">Niveau de risque</span>
                  {getRiskBadge(p.riskLevel)}
                </div>
                <div className="flex items-center justify-between py-2 border-b border-[#F0F0F0]">
                  <span className="text-sm text-[#6B7280]">Statut</span>
                  <span className="px-2 py-0.5 rounded text-xs font-medium bg-[#2C5F7C]/10 text-[#2C5F7C]">
                    {p.status === 'active' ? 'Active' : p.status === 'monitored' ? 'Surveillance' : p.status === 'postpartum' ? 'Post-partum' : 'Archivée'}
                  </span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-[#F0F0F0]">
                  <span className="text-sm text-[#6B7280]">Date de création</span>
                  <span className="text-sm text-[#1A1D1F]">{new Date(p.createdAt).toLocaleDateString('fr-FR')}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* === ANTHROPOMETRICS TAB === */}
        {activeTab === 'anthropometrics' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Données anthropométriques</h3>
              <div className="space-y-3">
                <Field label="Taille" value={`${p.anthropometric.height} cm`} />
                <Field label="Poids pré-gestationnel" value={`${p.anthropometric.prePregnancyWeight} kg`} />
                <Field label="Poids actuel" value={`${p.anthropometric.currentWeight} kg`} />
                <Field label="IMC pré-gestationnel" value={`${p.anthropometric.prePregnancyBMI} kg/m²`} highlight={p.anthropometric.prePregnancyBMI >= 30} />
                <Field label="IMC actuel" value={`${p.anthropometric.currentBMI} kg/m²`} />
                <Field label="Prise pondérale totale" value={`+${p.anthropometric.totalWeightGain} kg`} highlight={p.anthropometric.totalWeightGain > 12} />
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Historique pondéral</h3>
              <div className="space-y-2">
                {p.anthropometric.weightHistory.map((entry, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-[#F0F0F0]">
                    <span className="text-sm text-[#6B7280]">{new Date(entry.date).toLocaleDateString('fr-FR')}</span>
                    <span className="text-sm font-medium text-[#1A1D1F]">{entry.weight} kg</span>
                  </div>
                ))}
              </div>
              {/* Weight progress bar */}
              <div className="mt-6">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-[#6B7280]">Progression poids</span>
                  <span className="text-[#1A1D1F] font-medium">{p.anthropometric.prePregnancyWeight} → {p.anthropometric.currentWeight} kg</span>
                </div>
                <div className="w-full h-2 bg-[#F0F0F0] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#2C5F7C] rounded-full transition-all"
                    style={{ width: `${Math.min((p.anthropometric.totalWeightGain / 15) * 100, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* === HISTORY TAB === */}
        {activeTab === 'history' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Obstetric */}
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider flex items-center gap-2">
                <Baby className="w-4 h-4 text-[#2C5F7C]" /> Obstétricaux
              </h3>
              <div className="space-y-3">
                <HistoryField label="Geste" value={`G${p.obstetricHistory.geste}`} />
                <HistoryField label="Parité" value={`P${p.obstetricHistory.parite}`} />
                <HistoryField label="Fausses couches" value={p.obstetricHistory.miscarriages} danger={p.obstetricHistory.miscarriages > 0} />
                <HistoryField label="MFIU" value={p.obstetricHistory.mfiu} danger={p.obstetricHistory.mfiu > 0} />
                <HistoryField label="Macrosomie" value={p.obstetricHistory.macrosomia ? 'Oui' : 'Non'} danger={p.obstetricHistory.macrosomia} />
                <HistoryField label="Prématurité" value={p.obstetricHistory.prematurity ? 'Oui' : 'Non'} danger={p.obstetricHistory.prematurity} />
                <HistoryField label="Prééclampsie" value={p.obstetricHistory.preeclampsia ? 'Oui' : 'Non'} danger={p.obstetricHistory.preeclampsia} />
                <HistoryField label="DG antérieur" value={p.obstetricHistory.previousGDM ? 'Oui' : 'Non'} danger={p.obstetricHistory.previousGDM} />
                <HistoryField label="Césarienne" value={p.obstetricHistory.csection ? 'Oui' : 'Non'} highlight={p.obstetricHistory.csection} />
              </div>
            </div>

            {/* Medical */}
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider flex items-center gap-2">
                <Heart className="w-4 h-4 text-[#EF4444]" /> Médicaux
              </h3>
              <div className="space-y-3">
                <HistoryField label="HTA" value={p.medicalHistory.hta ? 'Oui' : 'Non'} danger={p.medicalHistory.hta} />
                <HistoryField label="Dyslipidémie" value={p.medicalHistory.dyslipidemia ? 'Oui' : 'Non'} danger={p.medicalHistory.dyslipidemia} />
                <HistoryField label="Obésité" value={p.medicalHistory.obesity ? 'Oui' : 'Non'} danger={p.medicalHistory.obesity} />
                <HistoryField label="Pathologie thyroïdienne" value={p.medicalHistory.thyroidPathology ? 'Oui' : 'Non'} highlight={p.medicalHistory.thyroidPathology} />
                <HistoryField label="Cardiopathie" value={p.medicalHistory.heartDisease ? 'Oui' : 'Non'} danger={p.medicalHistory.heartDisease} />
                <HistoryField label="Néphropathie" value={p.medicalHistory.nephropathy ? 'Oui' : 'Non'} danger={p.medicalHistory.nephropathy} />
                {p.medicalHistory.other && <Field label="Autre" value={p.medicalHistory.other} />}
              </div>
            </div>

            {/* Family */}
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider flex items-center gap-2">
                <User className="w-4 h-4 text-[#F59E0B]" /> Familiaux
              </h3>
              <div className="space-y-3">
                <HistoryField label="Diabète" value={p.familyHistory.diabetes ? 'Oui' : 'Non'} danger={p.familyHistory.diabetes} />
                <HistoryField label="HTA" value={p.familyHistory.hta ? 'Oui' : 'Non'} danger={p.familyHistory.hta} />
                <HistoryField label="Obésité" value={p.familyHistory.obesity ? 'Oui' : 'Non'} highlight={p.familyHistory.obesity} />
                <HistoryField label="Maladies cardiovasculaires" value={p.familyHistory.cardiovascularDisease ? 'Oui' : 'Non'} danger={p.familyHistory.cardiovascularDisease} />
              </div>
            </div>
          </div>
        )}

        {/* === PREGNANCY TAB === */}
        {activeTab === 'pregnancy' && (
          <div className="max-w-2xl">
            <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Données de grossesse</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
                  <p className="text-xs text-[#6B7280] mb-1">Date dernières règles (DDR)</p>
                  <p className="text-lg font-semibold text-[#1A1D1F]">
                    {p.pregnancy.ddr ? new Date(p.pregnancy.ddr).toLocaleDateString('fr-FR') : 'Non renseignée'}
                  </p>
                </div>
                <div className="p-4 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
                  <p className="text-xs text-[#6B7280] mb-1">Date prévue d'accouchement (DPA)</p>
                  <p className="text-lg font-semibold text-[#1A1D1F]">
                    {p.pregnancy.dpa ? new Date(p.pregnancy.dpa).toLocaleDateString('fr-FR') : 'N/A'}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-md bg-[#2C5F7C]/5 border border-[#2C5F7C]/20 text-center">
                  <p className="text-xs text-[#2C5F7C] mb-1">Âge gestationnel</p>
                  <p className="text-3xl font-bold text-[#2C5F7C]">{p.pregnancy.sa || '--'}</p>
                  <p className="text-xs text-[#2C5F7C]/70">semaines</p>
                </div>
                <div className="p-4 rounded-md bg-[#F59E0B]/5 border border-[#F59E0B]/20 text-center">
                  <p className="text-xs text-[#F59E0B] mb-1">Trimestre</p>
                  <p className="text-3xl font-bold text-[#F59E0B]">{p.pregnancy.trimester || '--'}</p>
                  <p className="text-xs text-[#F59E0B]/70">
                    {p.pregnancy.trimester === 1 ? '1er' : p.pregnancy.trimester === 2 ? '2ème' : p.pregnancy.trimester === 3 ? '3ème' : ''}
                  </p>
                </div>
                <div className="p-4 rounded-md bg-[#10B981]/5 border border-[#10B981]/20 text-center">
                  <p className="text-xs text-[#10B981] mb-1">Jours restants</p>
                  <p className="text-3xl font-bold text-[#10B981]">
                    {p.pregnancy.dpa ? Math.max(0, Math.ceil((new Date(p.pregnancy.dpa).getTime() - new Date('2025-04-15').getTime()) / (1000 * 60 * 60 * 24))) : '--'}
                  </p>
                  <p className="text-xs text-[#10B981]/70">jours</p>
                </div>
              </div>
              {/* Gestational progress bar */}
              {p.pregnancy.sa && (
                <div className="mt-4">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-[#6B7280]">Progression de la grossesse</span>
                    <span className="text-[#1A1D1F] font-medium">{p.pregnancy.sa} / 40 SA</span>
                  </div>
                  <div className="w-full h-3 bg-[#F0F0F0] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min((p.pregnancy.sa / 40) * 100, 100)}%`,
                        background: `linear-gradient(90deg, #10B981 0%, #F59E0B 50%, #EF4444 100%)`,
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-[#9CA3AF] mt-1">
                    <span>T1 (0-12 SA)</span>
                    <span>T2 (13-28 SA)</span>
                    <span>T3 (29-40 SA)</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* === DIABETES TAB === */}
        {activeTab === 'diabetes' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Caractéristiques du diabète</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between py-2 border-b border-[#F0F0F0]">
                  <span className="text-sm text-[#6B7280]">Type</span>
                  <span className="px-2 py-0.5 rounded text-xs font-medium bg-[#2C5F7C]/10 text-[#2C5F7C]">
                    {p.diabetes.type === 'dg' ? 'Diabète gestationnel' : p.diabetes.type === 'dt1' ? 'Diabète type 1' : p.diabetes.type === 'dt2' ? 'Diabète type 2' : 'Autre'}
                  </span>
                </div>
                <Field label="Date du diagnostic" value={p.diabetes.diagnosisDate ? new Date(p.diabetes.diagnosisDate).toLocaleDateString('fr-FR') : 'N/A'} />
                {p.diabetes.diabetesDuration !== undefined && p.diabetes.diabetesDuration !== null && (
                  <Field label="Ancienneté du diabète" value={`${p.diabetes.diabetesDuration} ans`} />
                )}
                {p.diabetes.preconceptionConsultation !== undefined && (
                  <Field label="Consultation préconceptionnelle" value={p.diabetes.preconceptionConsultation ? 'Oui' : 'Non'} />
                )}
                {p.diabetes.preconceptionHbA1c !== undefined && p.diabetes.preconceptionHbA1c !== null && (
                  <Field label="HbA1c préconceptionnelle" value={`${p.diabetes.preconceptionHbA1c}%`} />
                )}
                {p.diabetes.existingComplications && (
                  <Field label="Complications préexistantes" value={p.diabetes.existingComplications} />
                )}
              </div>

              {/* HGPO */}
              {p.diabetes.hgpo75g && (
                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">HGPO 75g</h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="p-3 rounded-md bg-[#F8F9FA] border border-[#E5E7EB] text-center">
                        <p className="text-[10px] text-[#6B7280]">À jeun</p>
                        <p className={`text-lg font-bold ${(p.diabetes.hgpo75g.fasting || 0) >= 0.92 ? 'text-[#EF4444]' : 'text-[#1A1D1F]'}`}>
                          {p.diabetes.hgpo75g.fasting} g/L
                        </p>
                        <p className="text-[10px] text-[#9CA3AF]">N: &lt;0.92</p>
                      </div>
                      <div className="p-3 rounded-md bg-[#F8F9FA] border border-[#E5E7EB] text-center">
                        <p className="text-[10px] text-[#6B7280]">1 heure</p>
                        <p className={`text-lg font-bold ${(p.diabetes.hgpo75g.oneHour || 0) >= 10.0 ? 'text-[#EF4444]' : 'text-[#1A1D1F]'}`}>
                          {p.diabetes.hgpo75g.oneHour} g/L
                        </p>
                        <p className="text-[10px] text-[#9CA3AF]">N: &lt;10.0</p>
                      </div>
                      <div className="p-3 rounded-md bg-[#F8F9FA] border border-[#E5E7EB] text-center">
                        <p className="text-[10px] text-[#6B7280]">2 heures</p>
                        <p className={`text-lg font-bold ${(p.diabetes.hgpo75g.twoHours || 0) >= 8.5 ? 'text-[#EF4444]' : 'text-[#1A1D1F]'}`}>
                          {p.diabetes.hgpo75g.twoHours} g/L
                        </p>
                        <p className="text-[10px] text-[#9CA3AF]">N: &lt;8.5</p>
                      </div>
                    </div>
                    {p.diabetes.hgpo75g.interpretation && (
                      <div className="p-3 rounded-md bg-[#2C5F7C]/5 border border-[#2C5F7C]/20">
                        <p className="text-xs text-[#2C5F7C] font-medium">{p.diabetes.hgpo75g.interpretation}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Traitements</h3>
              <div className="space-y-2">
                <TreatmentToggle label="Régime diététique" active={p.diabetes.treatments.diet} />
                <TreatmentToggle label="Activité physique" active={p.diabetes.treatments.physicalActivity} />
                <TreatmentToggle label="Metformine" active={p.diabetes.treatments.metformin} />
                <TreatmentToggle label="Insuline basale" active={p.diabetes.treatments.basalInsulin} />
                <TreatmentToggle label="Insuline rapide" active={p.diabetes.treatments.rapidInsulin} />
                <TreatmentToggle label="Pompe à insuline" active={p.diabetes.treatments.insulinPump} />
                <TreatmentToggle label="Boucle fermée hybride" active={p.diabetes.treatments.hybridClosedLoop} />
              </div>
            </div>
          </div>
        )}

        {/* === CONSULTATIONS TAB === */}
        {activeTab === 'consultations' && (
          <div>
            <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4 uppercase tracking-wider">Historique des consultations</h3>
            {p.consultations.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-10 h-10 text-[#E5E7EB] mx-auto mb-3" />
                <p className="text-[#6B7280] text-sm">Aucune consultation enregistrée</p>
              </div>
            ) : (
              <div className="space-y-4">
                {p.consultations.map(consult => (
                  <div key={consult.id} className="p-4 rounded-md border border-[#E5E7EB] hover:border-[#2C5F7C]/30 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-semibold text-[#2C5F7C]">{new Date(consult.date).toLocaleDateString('fr-FR')}</span>
                      <span className="text-xs text-[#6B7280]">{consult.motif}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-xs text-[#6B7280] mb-0.5">Examen clinique</p>
                        <p className="text-[#1A1D1F]">{consult.clinicalExam}</p>
                      </div>
                      <div>
                        <p className="text-xs text-[#6B7280] mb-0.5">Diagnostic</p>
                        <p className="text-[#1A1D1F] font-medium">{consult.diagnosis}</p>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-[#F0F0F0]">
                      <p className="text-xs text-[#6B7280] mb-0.5">Conduite à tenir</p>
                      <p className="text-sm text-[#1A1D1F]">{consult.treatmentPlan}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// --- Sub-components ---

function Field({ label, value, highlight = false }: { label: string; value: string | number; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-[#F0F0F0]">
      <span className="text-sm text-[#6B7280]">{label}</span>
      <span className={`text-sm font-medium ${highlight ? 'text-[#EF4444]' : 'text-[#1A1D1F]'}`}>{value}</span>
    </div>
  );
}

function HistoryField({ label, value, danger = false, highlight = false }: { label: string; value: string | number; danger?: boolean; highlight?: boolean }) {
  const isPositive = typeof value === 'string' && (value === 'Oui' || value.startsWith('G') || value.startsWith('P'));
  return (
    <div className="flex items-center justify-between py-2 border-b border-[#F0F0F0]">
      <span className="text-sm text-[#6B7280]">{label}</span>
      <span className={`text-sm font-medium ${danger ? 'text-[#EF4444]' : highlight || isPositive ? 'text-[#F59E0B]' : 'text-[#1A1D1F]'}`}>{value}</span>
    </div>
  );
}

function TreatmentToggle({ label, active }: { label: string; active: boolean }) {
  return (
    <div className="flex items-center justify-between py-2.5 px-3 rounded-md border border-[#E5E7EB]">
      <span className="text-sm text-[#1A1D1F]">{label}</span>
      <div className={`w-11 h-6 rounded-full relative transition-colors ${active ? 'bg-[#10B981]' : 'bg-[#E5E7EB]'}`}>
        <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${active ? 'translate-x-5' : 'translate-x-0.5'}`} />
      </div>
    </div>
  );
}
