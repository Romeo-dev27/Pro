import { useMemo } from 'react';
import { useStore } from '@/store/useStore';
import { mockBiologyEntries } from '@/store/mockData';
import { ArrowLeft, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import {
  LineChart, Line,
  ResponsiveContainer
} from 'recharts';

interface BioMarker {
  key: string;
  label: string;
  unit: string;
  normalMin: number | null;
  normalMax: number | null;
  getValue: (entry: typeof mockBiologyEntries[0]) => number | null;
}

const markers: BioMarker[] = [
  { key: 'hba1c', label: 'HbA1c', unit: '%', normalMin: 4, normalMax: 6.5, getValue: e => e.hba1c ?? null },
  { key: 'creatinine', label: 'Créatinine', unit: 'μmol/L', normalMin: 45, normalMax: 84, getValue: e => e.creatinine ?? null },
  { key: 'urea', label: 'Urée', unit: 'mmol/L', normalMin: 2.5, normalMax: 7.1, getValue: e => e.urea ?? null },
  { key: 'asat', label: 'ASAT', unit: 'U/L', normalMin: 10, normalMax: 35, getValue: e => e.asat ?? null },
  { key: 'alat', label: 'ALAT', unit: 'U/L', normalMin: 7, normalMax: 56, getValue: e => e.alat ?? null },
  { key: 'tsh', label: 'TSH', unit: 'mUI/L', normalMin: 0.4, normalMax: 4.0, getValue: e => e.tsh ?? null },
  { key: 'albuminuria', label: 'Albuminurie', unit: 'mg/24h', normalMin: null, normalMax: 30, getValue: e => e.albuminuria ?? null },
];

export default function BiologyPage() {
  const { selectedPatient, selectPatient, setCurrentPage } = useStore();

  if (!selectedPatient) {
    return (
      <div className="text-center py-20">
        <p className="text-[#6B7280]">Sélectionnez une patiente pour voir ses résultats biologiques</p>
        <button onClick={() => setCurrentPage('patients')} className="mt-4 px-4 py-2 bg-[#2C5F7C] text-white rounded-md text-sm">Voir la liste</button>
      </div>
    );
  }

  const p = selectedPatient;
  const patientEntries = useMemo(() =>
    mockBiologyEntries.filter(e => e.patientId === p.id).sort((a, b) => a.date.localeCompare(b.date)),
    [p.id]
  );

  const getTrend = (values: (number | null)[]) => {
    const valid = values.filter(v => v !== null) as number[];
    if (valid.length < 2) return 'stable';
    const last = valid[valid.length - 1];
    const prev = valid[valid.length - 2];
    if (last > prev) return 'up';
    if (last < prev) return 'down';
    return 'stable';
  };

  const getStatusColor = (value: number | null, marker: BioMarker) => {
    if (value === null) return 'text-[#6B7280]';
    if (marker.normalMax !== null && value > marker.normalMax) return 'text-[#EF4444]';
    if (marker.normalMin !== null && value < marker.normalMin) return 'text-[#F59E0B]';
    return 'text-[#10B981]';
  };

  const getStatusBorder = (value: number | null, marker: BioMarker) => {
    if (value === null) return 'border-l-4 border-l-[#6B7280]';
    if (marker.normalMax !== null && value > marker.normalMax) return 'border-l-4 border-l-[#EF4444]';
    if (marker.normalMin !== null && value < marker.normalMin) return 'border-l-4 border-l-[#F59E0B]';
    return 'border-l-4 border-l-[#10B981]';
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => selectPatient(null)} className="p-2 rounded-lg hover:bg-[#F0F2F5] transition-colors">
          <ArrowLeft className="w-5 h-5 text-[#6B7280]" />
        </button>
        <div>
          <h2 className="text-lg font-semibold text-[#1A1D1F]">Biologie — {p.identity.lastName} {p.identity.firstName}</h2>
          <p className="text-xs text-[#6B7280]">{patientEntries.length} analyses enregistrées</p>
        </div>
      </div>

      {/* Markers grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {markers.map(marker => {
          const values = patientEntries.map(e => marker.getValue(e));
          const lastValue = values[values.length - 1] ?? null;
          const trend = getTrend(values);
          const chartData = patientEntries.map(e => ({
            date: e.date.slice(5),
            value: marker.getValue(e),
          }));

          return (
            <div key={marker.key} className={`bg-white rounded-md border border-[#E5E7EB] ${getStatusBorder(lastValue, marker)} p-5`}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-xs text-[#6B7280] uppercase tracking-wider">{marker.label}</p>
                  <p className={`text-3xl font-bold mt-1 ${getStatusColor(lastValue, marker)}`}>
                    {lastValue !== null ? lastValue : '--'}
                    <span className="text-sm font-normal text-[#6B7280] ml-1">{marker.unit}</span>
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  {trend === 'up' && <TrendingUp className="w-4 h-4 text-[#EF4444]" />}
                  {trend === 'down' && <TrendingDown className="w-4 h-4 text-[#10B981]" />}
                  {trend === 'stable' && <Minus className="w-4 h-4 text-[#6B7280]" />}
                </div>
              </div>

              {/* Normal range */}
              <p className="text-[10px] text-[#9CA3AF] mb-3">
                Normale: {marker.normalMin ?? '<'} — {marker.normalMax ?? '>'} {marker.unit}
              </p>

              {/* Sparkline */}
              {chartData.length > 1 && (
                <ResponsiveContainer width="100%" height={60}>
                  <LineChart data={chartData}>
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke={lastValue !== null && marker.normalMax !== null && lastValue > marker.normalMax ? '#EF4444' : '#2C5F7C'}
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}

              {/* History */}
              {patientEntries.length > 0 && (
                <div className="mt-3 pt-3 border-t border-[#F0F0F0] space-y-1">
                  {patientEntries.slice(-3).reverse().map(entry => {
                    const val = marker.getValue(entry);
                    return (
                      <div key={entry.id} className="flex items-center justify-between text-xs">
                        <span className="text-[#6B7280]">{new Date(entry.date).toLocaleDateString('fr-FR')}</span>
                        <span className={`font-medium ${getStatusColor(val, marker)}`}>{val !== null ? `${val} ${marker.unit}` : 'N/A'}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Full history table */}
      {patientEntries.length > 0 && (
        <div className="bg-white rounded-md border border-[#E5E7EB] overflow-x-auto">
          <div className="px-5 py-4 border-b border-[#E5E7EB]">
            <h3 className="text-sm font-semibold text-[#1A1D1F]">Historique complet</h3>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB]">
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280]">Date</th>
                {markers.map(m => (
                  <th key={m.key} className="text-center px-3 py-3 text-xs font-semibold text-[#6B7280]">{m.label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {patientEntries.map(entry => (
                <tr key={entry.id} className="border-b border-[#E5E7EB] hover:bg-[#F6F7F9]">
                  <td className="px-5 py-3 text-[#1A1D1F] font-medium">{new Date(entry.date).toLocaleDateString('fr-FR')}</td>
                  {markers.map(marker => {
                    const val = marker.getValue(entry);
                    return (
                      <td key={marker.key} className={`text-center px-3 py-3 font-medium ${getStatusColor(val, marker)}`}>
                        {val !== null ? val : '—'}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
