import { useState } from 'react';
import { useStore } from '@/store/useStore';
import {
  ArrowLeft, FileText, Printer, Download,
  Stethoscope, FlaskConical, Baby, Mail, ClipboardCheck
} from 'lucide-react';

type DocType = 'prescription' | 'lab_request' | 'echo_request' | 'certificate' | 'letter' | 'report';

const docTypes: { id: DocType; label: string; icon: typeof FileText }[] = [
  { id: 'prescription', label: 'Ordonnance', icon: FileText },
  { id: 'lab_request', label: 'Demande de bilan', icon: FlaskConical },
  { id: 'echo_request', label: 'Demande d\'échographie', icon: Baby },
  { id: 'certificate', label: 'Certificat médical', icon: ClipboardCheck },
  { id: 'letter', label: 'Lettre au gynécologue', icon: Mail },
  { id: 'report', label: 'Compte rendu', icon: Stethoscope },
];

const docTemplates: Record<DocType, string> = {
  prescription: `PRESCRIPTION MÉDICALE

Métformine 500 mg : 1 cp x 3/j repas
Insuline Glargine (Lantus) : 12 UI le soir
Insuline Aspart (Novorapid) : 4 UI avant chaque repas

Bandelettes réactives : 1 boîte
Aiguilles pour stylo : 1 boîte

Renouvellement x 3

Le médecin`,
  lab_request: `DEMANDE DE BILAN BIOLOGIQUE

□ NFS, Ferritine
□ Créatinine, Urée, Ionogramme
□ ASAT, ALAT, GGT, Bilirubine
□ TSH, T3 libre, T4 libre
□ HbA1c
□ Bilan lipidique
□ Albuminurie des 24h
□ ECBU

Merci de transmettre les résultats dès réception.`,
  echo_request: `DEMANDE D'ÉCHOGRAPHIE OBSTÉTRICALE

Grossesse suivie pour :
□ Diabète gestationnel
□ Diabète préexistant
□ Autre :

SA actuelles : _____

Demande :
□ Biométrie fœtale complète (BIP, PC, PA, LF)
□ Poids fœtal estimé et percentile
□ Doppler ombilical
□ Doppler cérébral (MCA)
□ Quantité de liquide amniotique
□ Morphologie fœtale

Risque de macrosomie : oui / non
Suivi de croissance : oui / non

Merci de transmettre le compte rendu.`,
  certificate: `CERTIFICAT MÉDICAL

Je soussigné(e), Docteur _________________,
médecin diabétologue, certifie avoir examiné ce jour :

Madame : ________________________
née le : ________________________

Le/la patiente présente une grossesse compliquée d'un diabète nécessitant un suivi spécialisé en consultation de diabétologie-obstétrique.

Arrêt de travail / Repos recommandé : oui / non
Durée : _____

Fait à _____________, le _____________

Signature et cachet du médecin`,
  letter: `LETTRE AU GYNÉCOLOGUE

À l'attention de Dr/Pr ________________________

 objet : Compte rendu de suivi diabétologique — Patient ________________________

Cher confrère/Chère consœur,

Je vous adresse le compte rendu de la patiente ________________________ (_____ ans),
suivie dans notre consultation de diabétologie-obstétrique pour :

□ Diabète gestationnel découvert à _____ SA
□ Diabète préexistant (Type 1 / Type 2)

Données actuelles :
• Terme actuel : _____ SA
• Équilibre glycémique : HbA1c = _____%
• Traitement en cours :
• Échographie du _____ : PFE _____g (_____e percentile)

Recommandations :

□ Surveillance glycémique satisfaisante, poursuite du suivi conjoint
□ Évaluation du mode d'accouchement recommandée (risque de macrosomie)
□ Délivrance programmée à _____ SA

Cordialement,

Dr ________________________
Diabétologue`,
  report: `COMPTE RENDU DE CONSULTATION

Date : ________________________
Patient : ________________________
N° Dossier : ________________________

Motif : ________________________

EXAMEN CLINIQUE :
TA : _____/_____ mmHg  FC : _____ bpm
Poids : _____ kg  Prise pondérale totale : +_____ kg

ANALYSE GLYCÉMIQUE :
Glycémies moyennes de la période : _____ mg/dL
% dans la cible : _____%
Nombre d'hyperglycémies : _____
Nombre d'hypoglycémies : _____

ANALYSE OBSTÉTRICALE :
Terme : _____ SA
Échographie du _____ : conforme / à surveiller

DIAGNOSTIC :

CONDUIT À TENIR :

PROCHAIN RENDEZ-VOUS :

Dr ________________________`,
};

export default function DocumentsPage() {
  const { selectedPatient, selectPatient, setCurrentPage, addToast } = useStore();
  const [selectedDocType, setSelectedDocType] = useState<DocType | null>(null);
  const [docContent, setDocContent] = useState('');

  if (!selectedPatient) {
    return (
      <div className="text-center py-20">
        <p className="text-[#6B7280]">Sélectionnez une patiente pour générer des documents</p>
        <button onClick={() => setCurrentPage('patients')} className="mt-4 px-4 py-2 bg-[#2C5F7C] text-white rounded-md text-sm">Voir la liste</button>
      </div>
    );
  }

  const p = selectedPatient;

  const handleSelectDocType = (type: DocType) => {
    setSelectedDocType(type);
    // Fill in patient info
    let content = docTemplates[type]
      .replace(/________________________/g, `${p.identity.lastName} ${p.identity.firstName}`)
      .replace(/_____/g, (match, offset, string) => {
        if (string.indexOf('SA') > offset - 20 && string.indexOf('SA') < offset + 20) {
          return p.pregnancy.sa?.toString() || '_____';
        }
        if (string.indexOf('kg') > offset - 20 && string.indexOf('kg') < offset + 20) {
          return p.anthropometric.currentWeight.toString();
        }
        return match;
      });
    setDocContent(content);
  };

  const handleExportPDF = () => {
    addToast('Document exporté en PDF', 'success');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => selectPatient(null)} className="p-2 rounded-lg hover:bg-[#F0F2F5] transition-colors">
          <ArrowLeft className="w-5 h-5 text-[#6B7280]" />
        </button>
        <div>
          <h2 className="text-lg font-semibold text-[#1A1D1F]">Documents — {p.identity.lastName} {p.identity.firstName}</h2>
        </div>
      </div>

      {!selectedDocType ? (
        /* Document type selection */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {docTypes.map(docType => {
            const Icon = docType.icon;
            return (
              <button
                key={docType.id}
                onClick={() => handleSelectDocType(docType.id)}
                className="bg-white rounded-md border border-[#E5E7EB] p-6 hover:border-[#2C5F7C] hover:shadow-sm transition-all text-left group"
              >
                <div className="w-12 h-12 rounded-lg bg-[#2C5F7C]/10 flex items-center justify-center mb-4 group-hover:bg-[#2C5F7C]/20 transition-colors">
                  <Icon className="w-6 h-6 text-[#2C5F7C]" />
                </div>
                <h3 className="text-sm font-semibold text-[#1A1D1F] mb-1">{docType.label}</h3>
                <p className="text-xs text-[#6B7280]">Générer un {docType.label.toLowerCase()}</p>
              </button>
            );
          })}
        </div>
      ) : (
        /* Document editor */
        <div className="bg-white rounded-md border border-[#E5E7EB] flex flex-col">
          <div className="flex items-center justify-between p-4 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-3">
              <button onClick={() => setSelectedDocType(null)} className="text-sm text-[#6B7280] hover:text-[#1A1D1F]">← Retour</button>
              <h3 className="text-sm font-semibold text-[#1A1D1F]">
                {docTypes.find(d => d.id === selectedDocType)?.label} — {p.identity.lastName} {p.identity.firstName}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={handlePrint} className="h-9 px-3 border border-[#E5E7EB] hover:bg-[#F0F2F5] text-[#6B7280] text-sm rounded-md transition-colors flex items-center gap-2">
                <Printer className="w-4 h-4" /> Imprimer
              </button>
              <button onClick={handleExportPDF} className="h-9 px-4 bg-[#2C5F7C] hover:bg-[#1E445A] text-white text-sm font-medium rounded-md transition-colors flex items-center gap-2">
                <Download className="w-4 h-4" /> Exporter PDF
              </button>
            </div>
          </div>
          <div className="p-6">
            <textarea
              value={docContent}
              onChange={(e) => setDocContent(e.target.value)}
              className="w-full h-[500px] p-6 font-mono text-sm text-[#1A1D1F] bg-[#F8F9FA] rounded-md border border-[#E5E7EB] focus:outline-none focus:border-[#2C5F7C] resize-none whitespace-pre-wrap"
            />
          </div>
        </div>
      )}
    </div>
  );
}
