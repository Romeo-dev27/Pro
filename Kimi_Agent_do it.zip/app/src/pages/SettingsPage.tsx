import { useStore } from '@/store/useStore';
import {
  User, Shield, Bell, Monitor,
  Save, CheckCircle
} from 'lucide-react';
import { useState } from 'react';

export default function SettingsPage() {
  const { user, addToast } = useStore();
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'notifications' | 'display'>('profile');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    addToast('Paramètres enregistrés', 'success');
    setTimeout(() => setSaved(false), 2000);
  };

  const tabs = [
    { id: 'profile' as const, label: 'Profil', icon: User },
    { id: 'security' as const, label: 'Sécurité', icon: Shield },
    { id: 'notifications' as const, label: 'Notifications', icon: Bell },
    { id: 'display' as const, label: 'Affichage', icon: Monitor },
  ];

  return (
    <div className="max-w-3xl">
      <h2 className="text-lg font-semibold text-[#1A1D1F] mb-6">Paramètres</h2>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#E5E7EB] mb-6">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-[#2C5F7C] text-[#2C5F7C]'
                  : 'border-transparent text-[#6B7280] hover:text-[#1A1D1F]'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <div className="bg-white rounded-md border border-[#E5E7EB] p-6">
        {/* Profile */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-[#2C5F7C] flex items-center justify-center text-xl font-bold text-white">
                {user?.name?.split(' ').map(n => n[0]).join('') || 'DR'}
              </div>
              <div>
                <p className="text-sm font-semibold text-[#1A1D1F]">{user?.name || 'Dr. Utilisateur'}</p>
                <p className="text-xs text-[#6B7280]">{user?.email || 'email@clinique.dz'}</p>
                <p className="text-xs text-[#6B7280]">Rôle : {user?.role === 'doctor' ? 'Médecin' : user?.role}</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[#6B7280] mb-1.5">Nom complet</label>
                <input type="text" defaultValue={user?.name} className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]" />
              </div>
              <div>
                <label className="block text-xs text-[#6B7280] mb-1.5">Email</label>
                <input type="email" defaultValue={user?.email} className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]" />
              </div>
              <div>
                <label className="block text-xs text-[#6B7280] mb-1.5">Spécialité</label>
                <input type="text" defaultValue="Diabétologie-Endocrinologie" className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]" />
              </div>
              <div>
                <label className="block text-xs text-[#6B7280] mb-1.5">N° RPPS</label>
                <input type="text" defaultValue="12345678901" className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]" />
              </div>
            </div>
          </div>
        )}

        {/* Security */}
        {activeTab === 'security' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Changer le mot de passe</h3>
              <div className="space-y-4 max-w-md">
                <div>
                  <label className="block text-xs text-[#6B7280] mb-1.5">Mot de passe actuel</label>
                  <input type="password" className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]" />
                </div>
                <div>
                  <label className="block text-xs text-[#6B7280] mb-1.5">Nouveau mot de passe</label>
                  <input type="password" className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]" />
                </div>
                <div>
                  <label className="block text-xs text-[#6B7280] mb-1.5">Confirmer le mot de passe</label>
                  <input type="password" className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]" />
                </div>
              </div>
            </div>
            <div className="pt-4 border-t border-[#E5E7EB]">
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Authentification à deux facteurs (2FA)</h3>
              <div className="flex items-center justify-between p-4 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
                <div>
                  <p className="text-sm text-[#1A1D1F]">Authentification à deux facteurs</p>
                  <p className="text-xs text-[#6B7280]">Sécurisez votre compte avec une vérification supplémentaire</p>
                </div>
                <div className="w-11 h-6 rounded-full bg-[#E5E7EB] relative cursor-pointer">
                  <div className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow" />
                </div>
              </div>
            </div>
            <div className="pt-4 border-t border-[#E5E7EB]">
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Sessions actives</h3>
              <div className="p-4 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#1A1D1F]">Cet appareil — Alger, Algérie</p>
                    <p className="text-xs text-[#6B7280]">Chrome sur Windows · Connecté aujourd'hui</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-xs font-medium bg-[#10B981]/10 text-[#10B981]">Actif</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Notifications */}
        {activeTab === 'notifications' && (
          <div className="space-y-4">
            {[
              { label: 'Alertes glycémiques', desc: 'Recevoir une notification en cas d\'hyperglycémie ou hypoglycémie', checked: true },
              { label: 'Nouveaux messages patients', desc: 'Notification lorsqu\'une patiente envoie un message', checked: true },
              { label: 'Rappels de rendez-vous', desc: 'Rappel 24h avant chaque consultation', checked: true },
              { label: 'Résultats biologiques', desc: 'Alerte lors de la réception de nouveaux résultats', checked: false },
              { label: 'Notifications email', desc: 'Recevoir les notifications par email', checked: false },
              { label: 'Notifications SMS', desc: 'Recevoir les alertes critiques par SMS', checked: true },
            ].map((notif, i) => (
              <div key={i} className="flex items-center justify-between p-4 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
                <div>
                  <p className="text-sm text-[#1A1D1F]">{notif.label}</p>
                  <p className="text-xs text-[#6B7280]">{notif.desc}</p>
                </div>
                <div className={`w-11 h-6 rounded-full relative cursor-pointer transition-colors ${notif.checked ? 'bg-[#10B981]' : 'bg-[#E5E7EB]'}`}>
                  <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${notif.checked ? 'translate-x-5 left-0.5' : 'translate-x-0.5 left-0.5'}`} />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Display */}
        {activeTab === 'display' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Apparence</h3>
              <div className="flex items-center gap-4">
                <button className="w-20 h-20 rounded-lg bg-white border-2 border-[#2C5F7C] flex items-center justify-center">
                  <span className="text-xs font-medium text-[#2C5F7C]">Clair</span>
                </button>
                <button className="w-20 h-20 rounded-lg bg-[#1A1D1F] border-2 border-transparent hover:border-[#6B7280] flex items-center justify-center">
                  <span className="text-xs font-medium text-white">Sombre</span>
                </button>
              </div>
            </div>
            <div className="pt-4 border-t border-[#E5E7EB]">
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Données affichées</h3>
              <div className="space-y-3">
                {[
                  { label: 'Afficher les courbes glycémiques par défaut', checked: true },
                  { label: 'Afficher les alertes sur le tableau de bord', checked: true },
                  { label: 'Afficher les objectifs sur les graphiques', checked: true },
                  { label: 'Mode compact pour les tableaux', checked: false },
                ].map((opt, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <input type="checkbox" defaultChecked={opt.checked} className="rounded border-[#E5E7EB] text-[#2C5F7C] focus:ring-[#2C5F7C]" />
                    <span className="text-sm text-[#1A1D1F]">{opt.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="pt-4 border-t border-[#E5E7EB]">
              <h3 className="text-sm font-semibold text-[#1A1D1F] mb-4">Unités</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[#6B7280] mb-1.5">Unité glycémie</label>
                  <select className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]">
                    <option>mg/dL</option>
                    <option>g/L</option>
                    <option>mmol/L</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#6B7280] mb-1.5">Unité poids</label>
                  <select className="w-full h-10 px-3 rounded-md border border-[#E5E7EB] text-sm focus:outline-none focus:border-[#2C5F7C]">
                    <option>kg</option>
                    <option>lbs</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Save button */}
        <div className="flex justify-end pt-6 border-t border-[#E5E7EB] mt-6">
          <button
            onClick={handleSave}
            className="h-10 px-6 bg-[#2C5F7C] hover:bg-[#1E445A] text-white text-sm font-medium rounded-md transition-colors flex items-center gap-2"
          >
            {saved ? <CheckCircle className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            {saved ? 'Enregistré !' : 'Enregistrer'}
          </button>
        </div>
      </div>
    </div>
  );
}
