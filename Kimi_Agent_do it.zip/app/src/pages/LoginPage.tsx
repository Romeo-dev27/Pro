import { useState } from 'react';
import { useStore } from '@/store/useStore';
import { Stethoscope, Eye, EyeOff, Shield, Lock } from 'lucide-react';

export default function LoginPage() {
  const { login, addToast } = useStore();
  const [email, setEmail] = useState('doc@dgpro.dz');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const success = login(email, password);
    if (!success) {
      addToast('Identifiants incorrects. Utilisez doc@dgpro.dz / n\'importe quel mot de passe', 'error');
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side - brand */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#1E3A4F] via-[#2C5F7C] to-[#3B7A99] flex-col justify-center items-center text-white p-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 rounded-full bg-white blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 rounded-full bg-white blur-3xl" />
        </div>
        <div className="relative z-10 text-center">
          <div className="w-20 h-20 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mx-auto mb-8 border border-white/20">
            <Stethoscope className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold mb-4">DiabeGest Pro</h1>
          <p className="text-lg text-white/80 mb-2">Plateforme de gestion des grossesses diabétiques</p>
          <p className="text-sm text-white/60 max-w-sm mx-auto">
            Solution médicale spécialisée pour le suivi des patientes en consultation diabétologie-obstétrique
          </p>
          <div className="mt-12 flex items-center gap-6 justify-center text-white/50 text-xs">
            <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> RGPD Compliant</span>
            <span className="flex items-center gap-1"><Lock className="w-3 h-3" /> Chiffrement AES-256</span>
          </div>
        </div>
      </div>

      {/* Right side - form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-white p-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden text-center mb-8">
            <div className="w-14 h-14 rounded-xl bg-[#2C5F7C] flex items-center justify-center mx-auto mb-4">
              <Stethoscope className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-[#1A1D1F]">DiabeGest Pro</h1>
          </div>

          <h2 className="text-2xl font-bold text-[#1A1D1F] mb-1">Connexion sécurisée</h2>
          <p className="text-sm text-[#6B7280] mb-8">Accédez à votre espace médecin</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-[#1A1D1F] mb-1.5">Adresse email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 px-4 rounded-md border border-[#E5E7EB] text-sm text-[#1A1D1F] focus:outline-none focus:border-[#2C5F7C] focus:ring-1 focus:ring-[#2C5F7C] transition-all"
                placeholder="doc@dgpro.dz"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#1A1D1F] mb-1.5">Mot de passe</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-11 px-4 pr-11 rounded-md border border-[#E5E7EB] text-sm text-[#1A1D1F] focus:outline-none focus:border-[#2C5F7C] focus:ring-1 focus:ring-[#2C5F7C] transition-all"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1"
                >
                  {showPassword ? <EyeOff className="w-4 h-4 text-[#6B7280]" /> : <Eye className="w-4 h-4 text-[#6B7280]" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2">
                <input type="checkbox" className="rounded border-[#E5E7EB] text-[#2C5F7C] focus:ring-[#2C5F7C]" defaultChecked />
                <span className="text-[#6B7280]">Rester connecté</span>
              </label>
              <button type="button" className="text-[#2C5F7C] hover:underline">Mot de passe oublié ?</button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-11 bg-[#2C5F7C] hover:bg-[#1E445A] text-white font-medium rounded-md transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2 active:scale-[0.98]"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Connexion...
                </>
              ) : (
                'Se connecter'
              )}
            </button>

            <p className="text-xs text-[#6B7280] text-center mt-4">
              Démo : utilisez <strong>doc@dgpro.dz</strong> avec n'importe quel mot de passe
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
