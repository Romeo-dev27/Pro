import { useStore } from '@/store/useStore';
import { ChevronRight, Filter, UserPlus, SearchX } from 'lucide-react';

export default function PatientsPage() {
  const {
    patients, selectPatient, setCurrentPage,
    searchQuery, riskFilter, setRiskFilter, statusFilter, setStatusFilter,
    addToast
  } = useStore();

  const filteredPatients = patients.filter(p => {
    const matchesSearch = !searchQuery ||
      `${p.identity.firstName} ${p.identity.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.identity.fileNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.identity.phone.includes(searchQuery);
    const matchesRisk = !riskFilter || p.riskLevel === riskFilter;
    const matchesStatus = !statusFilter || p.status === statusFilter;
    return matchesSearch && matchesRisk && matchesStatus;
  });

  const handlePatientClick = (id: string) => {
    selectPatient(id);
    setCurrentPage('patients');
  };

  const getRiskBadge = (risk: string) => {
    const map: Record<string, string> = {
      low: 'bg-[#10B981]/10 text-[#10B981]',
      medium: 'bg-[#F59E0B]/10 text-[#F59E0B]',
      high: 'bg-[#EF4444]/10 text-[#EF4444]',
      critical: 'bg-[#EF4444]/20 text-[#EF4444]',
    };
    const labels: Record<string, string> = { low: 'Faible', medium: 'Modéré', high: 'Élevé', critical: 'Critique' };
    return <span className={`px-2 py-0.5 rounded text-xs font-medium ${map[risk]}`}>{labels[risk]}</span>;
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, string> = {
      active: 'bg-[#2C5F7C]/10 text-[#2C5F7C]',
      monitored: 'bg-[#F59E0B]/10 text-[#F59E0B]',
      postpartum: 'bg-[#10B981]/10 text-[#10B981]',
      archived: 'bg-[#6B7280]/10 text-[#6B7280]',
    };
    const labels: Record<string, string> = { active: 'Active', monitored: 'Surveillance', postpartum: 'Post-partum', archived: 'Archivée' };
    return <span className={`px-2 py-0.5 rounded text-xs font-medium ${map[status]}`}>{labels[status]}</span>;
  };

  const getDiabetesLabel = (type: string) => {
    const labels: Record<string, string> = { dg: 'DG', dt1: 'DT1', dt2: 'DT2', other: 'Autre' };
    return labels[type] || type;
  };

  return (
    <div className="space-y-4">
      {/* Filters bar */}
      <div className="flex flex-wrap items-center gap-3 bg-white rounded-md border border-[#E5E7EB] p-4">
        <div className="flex items-center gap-2 text-sm text-[#6B7280]">
          <Filter className="w-4 h-4" />
          <span className="font-medium">Filtres :</span>
        </div>

        <select
          value={riskFilter || ''}
          onChange={(e) => setRiskFilter(e.target.value || null)}
          className="h-9 px-3 rounded-md border border-[#E5E7EB] text-sm text-[#1A1D1F] bg-white focus:outline-none focus:border-[#2C5F7C]"
        >
          <option value="">Tous les risques</option>
          <option value="low">Faible</option>
          <option value="medium">Modéré</option>
          <option value="high">Élevé</option>
          <option value="critical">Critique</option>
        </select>

        <select
          value={statusFilter || ''}
          onChange={(e) => setStatusFilter(e.target.value || null)}
          className="h-9 px-3 rounded-md border border-[#E5E7EB] text-sm text-[#1A1D1F] bg-white focus:outline-none focus:border-[#2C5F7C]"
        >
          <option value="">Tous les statuts</option>
          <option value="active">Active</option>
          <option value="monitored">Surveillance</option>
          <option value="postpartum">Post-partum</option>
          <option value="archived">Archivée</option>
        </select>

        {(riskFilter || statusFilter) && (
          <button
            onClick={() => { setRiskFilter(null); setStatusFilter(null); }}
            className="text-xs text-[#2C5F7C] hover:underline"
          >
            Réinitialiser
          </button>
        )}

        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-[#6B7280]">{filteredPatients.length} patient{filteredPatients.length > 1 ? 'es' : 'e'}</span>
          <button
            onClick={() => addToast('Fonctionnalité à venir dans la version complète', 'info')}
            className="h-9 px-4 bg-[#2C5F7C] hover:bg-[#1E445A] text-white text-sm font-medium rounded-md transition-colors flex items-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            Nouvelle patiente
          </button>
        </div>
      </div>

      {/* Patients table */}
      <div className="bg-white rounded-md border border-[#E5E7EB]">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB]">
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Patient</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">N° Dossier</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Grossesse</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Diabète</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Risque</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Statut</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Téléphone</th>
                <th className="px-5 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filteredPatients.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center">
                    <SearchX className="w-10 h-10 text-[#E5E7EB] mx-auto mb-3" />
                    <p className="text-[#6B7280] text-sm">Aucune patiente ne correspond aux critères</p>
                  </td>
                </tr>
              ) : (
                filteredPatients.map(patient => (
                  <tr
                    key={patient.id}
                    onClick={() => handlePatientClick(patient.id)}
                    className="border-b border-[#E5E7EB] hover:bg-[#F6F7F9] cursor-pointer transition-colors"
                  >
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-[#2C5F7C]/10 flex items-center justify-center text-xs font-semibold text-[#2C5F7C] flex-shrink-0">
                          {patient.identity.firstName[0]}{patient.identity.lastName[0]}
                        </div>
                        <div>
                          <p className="font-medium text-[#1A1D1F]">{patient.identity.lastName} {patient.identity.firstName}</p>
                          <p className="text-xs text-[#6B7280]">{patient.identity.age} ans</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-[#6B7280]">{patient.identity.fileNumber}</td>
                    <td className="px-5 py-3 text-[#6B7280]">
                      {patient.pregnancy.sa ? `${patient.pregnancy.sa} SA (T${patient.pregnancy.trimester})` : 'N/A'}
                    </td>
                    <td className="px-5 py-3">
                      <span className="text-xs font-medium text-[#1A1D1F]">{getDiabetesLabel(patient.diabetes.type)}</span>
                    </td>
                    <td className="px-5 py-3">{getRiskBadge(patient.riskLevel)}</td>
                    <td className="px-5 py-3">{getStatusBadge(patient.status)}</td>
                    <td className="px-5 py-3 text-[#6B7280]">{patient.identity.phone}</td>
                    <td className="px-5 py-3">
                      <ChevronRight className="w-4 h-4 text-[#9CA3AF]" />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
